import { Category, Product } from "./types";

export const CATEGORIES: Category[] = [
  { id: "skincare", name: "Skin Care", icon: "✨" },
  { id: "makeup", name: "Makeup", icon: "💄" },
  { id: "haircare", name: "Hair Care", icon: "🧴" },
  { id: "fragrance", name: "Fragrance", icon: "💫" },
  { id: "korean", name: "K-Beauty", icon: "🌸" },
  { id: "bodycare", name: "Body Care", icon: "🧼" },
  { id: "tools", name: "Tools", icon: "🧽" },
  { id: "wellness", name: "Wellness", icon: "🌿" },
];

export const PRODUCTS: Product[] = [
  {
    id: "p1",
    name: "Luminous Glow Vitamin C Serum",
    brand: "Glow & Co",
    price: 899,
    originalPrice: 1299,
    image: "https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&q=80&w=400",
    category: "skincare",
    rating: 4.8,
    reviews: 1245,
    isBestseller: true,
    tags: ["Vitamin C", "Brightening"],
    description: "Achieve radiant skin with our potent 15% Vitamin C serum. Fades dark spots and evens skin tone.",
    variants: [
      { id: "v1", weight: "30ml (0.2kg)", price: 899, stockQuantity: 50, color: "" },
      { id: "v2", weight: "1.2kg Value Pack", price: 2999, stockQuantity: 10, color: "" },
      { id: "v3", weight: "2.5kg Pro Salon", price: 5499, stockQuantity: 5, color: "" }
    ],
    weightInKg: 0.2
  },
  {
    id: "p2",
    name: "Velvet Matte Liquid Lipstick",
    brand: "Aura Beauty",
    price: 499,
    originalPrice: 799,
    image: "https://images.unsplash.com/photo-1586495777744-4413f21062fa?auto=format&fit=crop&q=80&w=400",
    category: "makeup",
    rating: 4.6,
    reviews: 890,
    isViral: true,
    isNew: true,
    tags: ["Long Lasting", "Matte"],
    description: "Highly pigmented, transfer-proof liquid lipstick that lasts up to 12 hours without drying your lips."
  },
  {
    id: "p3",
    name: "Rose Water Soothing Toner",
    brand: "Earth Naturals",
    price: 349,
    image: "https://images.unsplash.com/photo-1629198688000-71f23e745b6e?auto=format&fit=crop&q=80&w=400",
    category: "skincare",
    rating: 4.9,
    reviews: 3200,
    tags: ["Soothing", "Organic"],
    description: "Pure distilled rose water that instantly refreshes and hydrates your skin while balancing pH levels."
  },
  {
    id: "p4",
    name: "Intense Repair Hair Mask",
    brand: "Silk Routes",
    price: 699,
    originalPrice: 999,
    image: "https://images.unsplash.com/photo-1526947425960-945c6e72858f?auto=format&fit=crop&q=80&w=400",
    category: "haircare",
    rating: 4.7,
    reviews: 540,
    isNew: true,
    tags: ["Keratin", "Deep Conditioning"],
    description: "Revitalize damaged hair with our argan oil and keratin infused hair mask. Perfect for colored or treated hair."
  },
  {
    id: "p5",
    name: "Snail Mucin Essence",
    brand: "Seoul Secret",
    price: 1450,
    image: "https://images.unsplash.com/photo-1615397323675-0151121d5565?auto=format&fit=crop&q=80&w=400",
    category: "korean",
    rating: 4.9,
    reviews: 8500,
    isViral: true,
    isBestseller: true,
    isNew: true,
    tags: ["Hydration", "K-Beauty"],
    description: "The viral K-Beauty secret for glass skin. Formulated with 96% snail secretion filtrate for intense hydration."
  },
  {
    id: "p6",
    name: "Flawless Finish Foundation",
    brand: "Aura Beauty",
    price: 1199,
    originalPrice: 1499,
    image: "https://images.unsplash.com/photo-1631214500515-e4ace7c68d4a?auto=format&fit=crop&q=80&w=400",
    category: "makeup",
    rating: 4.5,
    reviews: 2100,
    tags: ["Buildable", "Dewy Finish"],
    description: "A lightweight, buildable foundation that seamlessly blends into the skin for a natural, dewy finish."
  }
];
