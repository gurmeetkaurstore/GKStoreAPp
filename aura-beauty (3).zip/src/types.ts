export interface Category {
  id: string;
  name: string;
  icon?: string;
  image?: string;
  parentId?: string;
}

export interface ProductVariant {
  id: string;
  weight: string;
  price: number;
  stockQuantity: number;
  color: string;
}

export interface OrderItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  image?: string;
  variantId?: string;
}

export interface Order {
  id: string;
  userId: string;
  userEmail?: string;
  customerName?: string;
  customerPhone?: string;
  paymentMethod?: string;
  status: 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
  total: number;
  subtotal?: number;
  shippingCost?: number;
  createdAt: string;
  trackingLink?: string;
  trackingNumber?: string;
  courierPartner?: string;
  razorpayPaymentId?: string;
  razorpayOrderId?: string;
  items: OrderItem[];
  shippingAddress?: {
    street: string;
    city: string;
    state: string;
    zipCode: string;
  };
}

export interface BannerSetting {
  id: string;
  imageUrl: string;
  mobileImageUrl: string;
  heading: string;
  subheading: string;
  saleText: string;
}

export interface Product {
  id: string;
  name: string;
  brand: string;
  price: number;
  originalPrice?: number;
  image: string;
  images?: string[];
  category: string;
  rating: number;
  reviews: number;
  isNew?: boolean;
  isBestseller?: boolean;
  isViral?: boolean;
  tags?: string[];
  description: string;
  weightInKg?: number;
  stockQuantity?: number;
  variants?: ProductVariant[];
}

export interface CartItem extends Product {
  quantity: number;
}
