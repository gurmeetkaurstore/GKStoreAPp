/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { HomeView } from './components/HomeView';
import { NavMenu } from './components/NavMenu';
import { CartView } from './components/CartView';
import { ProductModal } from './components/ProductModal';
import { AdminDashboard } from './components/AdminDashboard';
import { SearchView } from './components/SearchView';
import { MyOrdersView } from './components/MyOrdersView';
import { AddressBookView } from './components/AddressBookView';
import { SettingsView } from './components/SettingsView';
import { ProfileSubViewPlaceholder } from './components/ProfileSubViewPlaceholder';
import { LegalDocumentView } from './components/LegalDocumentView';
import { TrackingModal } from './components/TrackingModal';
import { Product, CartItem, Category, Order, BannerSetting } from './types';
import { CATEGORIES as INITIAL_CATEGORIES, PRODUCTS as INITIAL_PRODUCTS } from './data';
import { Search, Sparkles } from 'lucide-react';
import { auth, db, handleFirestoreError, OperationType } from './firebase';
import { collection, onSnapshot, doc, setDoc, deleteDoc, updateDoc, query, where } from 'firebase/firestore';
import { onAuthStateChanged, signInWithPopup, GoogleAuthProvider, signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut } from 'firebase/auth';

export default function App() {
  const [currentPath, setCurrentPath] = useState(window.location.pathname);
  const [activeTab, setActiveTab] = useState("home");
  const [initialSearchQuery, setInitialSearchQuery] = useState('');
  const [startCheckout, setStartCheckout] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [banners, setBanners] = useState<BannerSetting[]>([]);
  const [orders, setOrders] = useState<any[]>([]);
  const [user, setUser] = useState(auth.currentUser);
  
  // Admin login states
  const [adminId, setAdminId] = useState("");
  const [adminPass, setAdminPass] = useState("");

  // User auth states
  const [userEmail, setUserEmail] = useState("");
  const [userPass, setUserPass] = useState("");
  const [userPhone, setUserPhone] = useState("");
  const [isLoginMode, setIsLoginMode] = useState(true);

  useEffect(() => {
    const onLocationChange = () => setCurrentPath(window.location.pathname);
    window.addEventListener('popstate', onLocationChange);
    return () => window.removeEventListener('popstate', onLocationChange);
  }, []);

  useEffect(() => {
    const unsubscribeAuth = onAuthStateChanged(auth, (u) => {
      setUser(u);
    });

    const unsubscribeCategories = onSnapshot(collection(db, 'categories'), (snapshot) => {
      const cats: Category[] = [];
      snapshot.forEach(doc => {
        cats.push(doc.data() as Category);
      });
      setCategories(cats);
    }, (error) => handleFirestoreError(error, OperationType.GET, 'categories'));

    const unsubscribeProducts = onSnapshot(collection(db, 'products'), (snapshot) => {
      const prods: Product[] = [];
      snapshot.forEach(doc => {
        prods.push(doc.data() as Product);
      });
      setProducts(prods);
    }, (error) => handleFirestoreError(error, OperationType.GET, 'products'));

    const unsubscribeBanner = onSnapshot(doc(db, 'settings', 'banners'), (document) => {
      if (document.exists() && document.data().bannersList) {
        setBanners(document.data().bannersList as BannerSetting[]);
      } else {
        setBanners([]);
      }
    }, (error) => console.log('Error fetching banners'));

    let unsubscribeOrders = () => {};
    const authUnsub = onAuthStateChanged(auth, (u) => {
      unsubscribeOrders();
      if (u) {
        if (u.email === 'gurmeetkaurstore@gmail.com') {
          unsubscribeOrders = onSnapshot(collection(db, 'orders'), (snapshot) => {
            const ords: any[] = [];
            snapshot.forEach(doc => {
              ords.push(doc.data());
            });
            setOrders(ords);
          }, (error) => handleFirestoreError(error, OperationType.GET, 'orders'));
        } else {
          unsubscribeOrders = onSnapshot(query(collection(db, 'orders'), where('userId', '==', u.uid)), (snapshot) => {
            const ords: any[] = [];
            snapshot.forEach(doc => {
              ords.push(doc.data());
            });
            setOrders(ords);
          }, (error) => handleFirestoreError(error, OperationType.GET, 'orders'));
        }
      } else {
        setOrders([]);
      }
    });

    return () => {
      unsubscribeAuth();
      unsubscribeCategories();
      unsubscribeProducts();
      unsubscribeBanner();
      unsubscribeOrders();
      authUnsub();
    };
  }, []);

  const loginAdmin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (adminId === 'GKadmin' && adminPass === 'Gupta@1234') {
      try {
        await signInWithEmailAndPassword(auth, 'gurmeetkaurstore@gmail.com', 'Gupta@1234');
      } catch (err: any) {
        try {
          await createUserWithEmailAndPassword(auth, 'gurmeetkaurstore@gmail.com', 'Gupta@1234');
        } catch (createErr) {
          console.error(createErr);
          alert('Failed to login admin.');
        }
      }
    } else {
      alert("Invalid Admin Credentials");
    }
  };

  const handleUserAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (isLoginMode) {
        await signInWithEmailAndPassword(auth, userEmail, userPass);
      } else {
        const userCred = await createUserWithEmailAndPassword(auth, userEmail, userPass);
        if (userPhone && userCred.user) {
           await setDoc(doc(db, 'users', userCred.user.uid), { phone: userPhone }, { merge: true });
        }
      }
      setUserEmail("");
      setUserPass("");
      setUserPhone("");
    } catch (err: any) {
      alert(err.message);
    }
  };

  const handleRestoreData = async () => {
    if(!confirm("Restore initial demo categories and products? This will add missing ones back.")) return;
    try {
      for (const cat of INITIAL_CATEGORIES) {
        await setDoc(doc(db, 'categories', cat.id), cat);
      }
      for (const prod of INITIAL_PRODUCTS) {
        await setDoc(doc(db, 'products', prod.id), prod);
      }
      alert('Demo data restored successfully!');
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'restore');
    }
  };

  const cartCount = cart.reduce((acc, item) => acc + item.quantity, 0);

  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [profileSubView, setProfileSubView] = useState<string | null>(null);
  const [isTrackModalOpen, setIsTrackModalOpen] = useState(false);
  const [trackOrderIdToOpen, setTrackOrderIdToOpen] = useState("");

  const showToast = (message: string) => {
    setToastMessage(message);
    setTimeout(() => {
      setToastMessage(null);
    }, 2500);
  };

  const addToCart = (product: Product) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { ...product, quantity: 1 }];
    });
    showToast("The Product has been Add to Cart");
  };

  const updateQuantity = (id: string, quantity: number) => {
    if (quantity === 0) {
      setCart((prev) => prev.filter((item) => item.id !== id));
      return;
    }
    setCart((prev) =>
      prev.map((item) => (item.id === id ? { ...item, quantity } : item))
    );
  };

  const removeItem = (id: string) => updateQuantity(id, 0);

  const handleAddCategory = async (cat: Category) => {
    try {
      await setDoc(doc(db, 'categories', cat.id), cat);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, `categories/${cat.id}`);
    }
  };

  const handleUpdateCategory = async (updatedCat: Category) => {
    try {
      await updateDoc(doc(db, 'categories', updatedCat.id), { ...updatedCat });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `categories/${updatedCat.id}`);
    }
  };

  const handleDeleteCategory = async (id: string) => {
    if(!confirm("Are you sure?")) return;
    try {
      await deleteDoc(doc(db, 'categories', id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `categories/${id}`);
    }
  };

  const handleAddProduct = async (prod: Product) => {
    try {
      await setDoc(doc(db, 'products', prod.id), prod);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, `products/${prod.id}`);
    }
  };

  const handleUpdateProduct = async (updatedProd: Product) => {
    try {
      await updateDoc(doc(db, 'products', updatedProd.id), { ...updatedProd });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `products/${updatedProd.id}`);
    }
  };

  const handleUpdateBanners = async (bannersData: BannerSetting[]) => {
    try {
      await setDoc(doc(db, 'settings', 'banners'), { bannersList: bannersData });
      alert('Banners updated successfully!');
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, 'settings/banners');
    }
  };

  const handleDeleteProduct = async (id: string) => {
    if(!confirm("Are you sure?")) return;
    try {
      await deleteDoc(doc(db, 'products', id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `products/${id}`);
    }
  };

  const handleUpdateOrderStatus = async (orderId: string, status: string, trackingLink?: string, courierPartner?: string, trackingNumber?: string) => {
    try {
      const updateData: any = { status };
      if (trackingLink !== undefined) {
        updateData.trackingLink = trackingLink;
      }
      if (courierPartner !== undefined) {
        updateData.courierPartner = courierPartner;
      }
      if (trackingNumber !== undefined) {
        updateData.trackingNumber = trackingNumber;
      }
      await updateDoc(doc(db, 'orders', orderId), updateData);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `orders/${orderId}`);
    }
  };

  const handleTrackOrder = () => {
    setTrackOrderIdToOpen("");
    setIsTrackModalOpen(true);
  };

  const handleCheckout = async (details: any) => {
    if (!user) {
      alert("Please login to place an order.");
      setActiveTab('profile');
      return;
    }
    const orderId = `o-${Date.now()}`;
    const subtotal = cart.reduce((acc, item) => acc + item.price * item.quantity, 0);
    const totalWeightInKg = cart.reduce((acc, item) => acc + (item.weightInKg || 1) * item.quantity, 0);
    const shippingCost = Math.ceil(totalWeightInKg) * 80;
    const totalAmount = subtotal + shippingCost;
    
    // Create base order data placeholder
    const createOrderData = (paymentMethod: string, status: 'pending' | 'processing') => ({
      id: orderId,
      userId: user.uid,
      userEmail: user.email || '',
      customerName: details.name,
      customerPhone: details.phone,
      paymentMethod,
      status,
      total: totalAmount,
      subtotal,
      shippingCost,
      createdAt: new Date().toISOString(),
      items: cart.map(item => ({
        id: item.id,
        name: item.name,
        price: item.price,
        quantity: item.quantity,
        image: item.image,
      })),
      shippingAddress: {
        street: details.address,
        city: details.city,
        state: details.state,
        zipCode: details.zipCode,
      }
    });

    if (details.paymentMethod === 'card' || details.paymentMethod === 'upi' || details.paymentMethod === 'razorpay') {
      try {
        const orderResponse = await fetch("/api/create-razorpay-order", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ amount: totalAmount }),
        });

        if (!orderResponse.ok) {
          const errData = await orderResponse.json();
          throw new Error(errData.error || "Failed to create Razorpay order.");
        }
        
        const rzpOrder = await orderResponse.json();
        
        const keyResponse = await fetch("/api/razorpay-key");
        const keyData = await keyResponse.json();

        const options = {
          key: keyData.key,
          amount: Math.round(totalAmount * 100),
          currency: "INR",
          name: "Gurmeet Kaur Store",
          description: "Purchase from Gurmeet Kaur Store",
          image: "/logo.jpg",
          order_id: rzpOrder.id,
          handler: async function (response: any) {
             const finalOrderData = createOrderData("Online (Razorpay)", "processing");
             // append razorpay reference
             Object.assign(finalOrderData, {
                razorpayPaymentId: response.razorpay_payment_id,
                razorpayOrderId: response.razorpay_order_id,
             });
             try {
               await setDoc(doc(db, 'orders', orderId), finalOrderData);
               setCart([]);
               alert("Payment Successful! Order placed.");
               setActiveTab('home');
             } catch (error) {
               handleFirestoreError(error, OperationType.CREATE, `orders/${orderId}`);
             }
          },
          prefill: {
            name: details.name,
            email: user.email || '',
            contact: details.phone || '',
          },
          theme: {
            color: "#F27D9A"
          }
        };

        const rzp = new (window as any).Razorpay(options);
        rzp.on('payment.failed', function (response: any){
           alert("Payment failed: " + response.error.description);
        });
        rzp.open();
        
      } catch (err: any) {
        alert(err.message);
      }
      return; 
    }

    // COD Flow
    const finalOrderData = createOrderData("Cash on Delivery", "pending");
    try {
      await setDoc(doc(db, 'orders', orderId), finalOrderData as any);
      setCart([]);
      alert("Order placed successfully via COD!");
      setActiveTab('home');
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, `orders/${orderId}`);
    }
  };

  if (currentPath === '/admin') {
    if (!user || user.email !== 'gurmeetkaurstore@gmail.com') {
      return (
        <div className="min-h-screen flex items-center justify-center bg-[#FFF8F9]">
          <form onSubmit={loginAdmin} className="bg-white p-8 rounded-3xl shadow-sm border border-[#FDE2E7] text-center max-w-sm w-full mx-4">
            <h1 className="text-2xl font-bold text-[#3D2B2B] mb-6">Admin Login</h1>
            <input 
              type="text" 
              placeholder="User Id" 
              value={adminId} 
              onChange={e => setAdminId(e.target.value)} 
              required
              className="w-full mb-4 px-4 py-3 rounded-xl border border-[#FDE2E7] bg-[#FFF8F9] focus:outline-none focus:ring-2 focus:ring-[#F27D9A]/50 text-sm font-medium text-[#4A3B3B]"
            />
            <input 
              type="password" 
              placeholder="Password" 
              value={adminPass} 
              onChange={e => setAdminPass(e.target.value)} 
              required
              className="w-full mb-6 px-4 py-3 rounded-xl border border-[#FDE2E7] bg-[#FFF8F9] focus:outline-none focus:ring-2 focus:ring-[#F27D9A]/50 text-sm font-medium text-[#4A3B3B]"
            />
            <button type="submit" className="bg-[#F27D9A] text-white px-6 py-3 rounded-xl font-bold hover:bg-[#E06D8A] transition-colors w-full">
              Login as Admin
            </button>
          </form>
        </div>
      );
    }

    return (
      <div className="relative">
        <AdminDashboard 
          categories={categories} 
          products={products}
          orders={orders}
          banners={banners}
          onUpdateBanners={handleUpdateBanners}
          onAddCategory={handleAddCategory} 
          onUpdateCategory={handleUpdateCategory}
          onDeleteCategory={handleDeleteCategory}
          onAddProduct={handleAddProduct}
          onUpdateProduct={handleUpdateProduct}
          onDeleteProduct={handleDeleteProduct}
          onRestoreData={handleRestoreData}
          onUpdateOrderStatus={handleUpdateOrderStatus}
        />
      </div>
    );
  }

  // Render different views based on active tab
  const renderView = () => {
    switch (activeTab) {
      case "home":
        return <HomeView 
          onProductClick={setSelectedProduct} 
          onNavigate={(tab) => {
            if (tab === 'search') setInitialSearchQuery('');
            setActiveTab(tab);
          }} 
          onCategoryClick={(catName) => {
            setInitialSearchQuery(catName);
            setActiveTab('search');
          }}
          categories={categories} 
          products={products} 
          banners={banners} 
          onAddToCart={addToCart} 
          onTrackOrder={handleTrackOrder} 
        />;
      case "cart":
        return (
          <CartView
            items={cart}
            updateQuantity={updateQuantity}
            removeItem={removeItem}
            userId={user?.uid}
            onCheckout={(details) => {
              handleCheckout(details);
              setStartCheckout(false);
            }}
            onCancelCheckout={() => setStartCheckout(false)}
            startCheckout={startCheckout}
          />
        );
      case "search":
        return (
          <SearchView 
            products={products} 
            onProductClick={setSelectedProduct} 
            onAddToCart={addToCart} 
            initialQuery={initialSearchQuery}
          />
        );
      case "ai":
        return (
          <div className="flex flex-col items-center justify-center h-[70vh] px-4 text-center">
            <div className="w-16 h-16 bg-gradient-to-tr from-brand-primary to-brand-secondary rounded-full flex items-center justify-center mb-4 text-white shadow-sm">
              <Sparkles size={28} />
            </div>
            <h2 className="text-xl font-bold text-text-dark mb-2">AI Skin Match</h2>
            <p className="text-gray-400 text-sm max-w-xs italic">Take a quick selfie to get personalized skincare routine recommendations.</p>
            <button onClick={() => alert("Starting AI Analysis...")} className="mt-6 bg-brand-primary text-white rounded-xl px-6 py-2.5 text-sm font-bold shadow-sm">Start Analysis</button>
          </div>
        );
      case "profile":
        if (profileSubView) {
          if (profileSubView === 'My Orders') {
            return <MyOrdersView orders={orders.filter(o => o.userId === user?.uid)} onBack={() => setProfileSubView(null)} onTrackOrder={(order) => {
              setTrackOrderIdToOpen(order.id);
              setIsTrackModalOpen(true);
            }} />;
          }
          if (profileSubView === 'Addresses' && user?.uid) {
            return <AddressBookView userId={user.uid} onBack={() => setProfileSubView(null)} />;
          }
          if (profileSubView === 'Settings') {
            return <SettingsView onBack={() => setProfileSubView(null)} onNavigateSubView={(view) => setProfileSubView(view)} />;
          }
          if (profileSubView === 'Privacy Policy' || profileSubView === 'Terms of Service') {
            return <LegalDocumentView title={profileSubView} onBack={() => setProfileSubView('Settings')} />;
          }
          return <ProfileSubViewPlaceholder title={profileSubView} onBack={() => setProfileSubView(null)} />;
        }
        if (!user) {
          return (
            <div className="flex flex-col items-center justify-center h-[70vh] px-4 text-center">
              <div className="w-24 h-24 mb-6 rounded-2xl overflow-hidden flex items-center justify-center">
                <img src="/logo.jpg" alt="Gurmeet Kaur Store Logo" className="w-[100px] h-[100px] object-contain rounded-2xl shadow-sm" />
              </div>
              <h2 className="text-xl font-bold text-text-dark mb-6">{isLoginMode ? 'Welcome Back' : 'Create Account'}</h2>
              
              <form onSubmit={handleUserAuth} className="w-full max-w-xs flex flex-col gap-4">
                <input
                  type="email"
                  placeholder="Email"
                  value={userEmail}
                  onChange={e => setUserEmail(e.target.value)}
                  required
                  className="w-full px-4 py-3 rounded-xl border border-brand-muted bg-brand-soft focus:outline-none focus:ring-2 focus:ring-brand-primary/50 text-sm font-medium text-text-main"
                />
                {!isLoginMode && (
                  <input
                    type="tel"
                    placeholder="Phone Number"
                    value={userPhone}
                    onChange={e => setUserPhone(e.target.value)}
                    required
                    className="w-full px-4 py-3 rounded-xl border border-brand-muted bg-brand-soft focus:outline-none focus:ring-2 focus:ring-brand-primary/50 text-sm font-medium text-text-main"
                  />
                )}
                <input
                  type="password"
                  placeholder="Password"
                  value={userPass}
                  onChange={e => setUserPass(e.target.value)}
                  required
                  className="w-full px-4 py-3 rounded-xl border border-brand-muted bg-brand-soft focus:outline-none focus:ring-2 focus:ring-brand-primary/50 text-sm font-medium text-text-main"
                />
                
                <button type="submit" className="mt-2 bg-brand-primary text-white rounded-xl px-6 py-3 text-sm font-bold shadow-sm transition-colors hover:bg-brand-secondary">
                  {isLoginMode ? 'Sign In' : 'Sign Up'}
                </button>
              </form>
              
              <button 
                onClick={() => setIsLoginMode(!isLoginMode)}
                className="mt-6 text-sm text-gray-500 hover:text-brand-primary font-medium"
              >
                {isLoginMode ? "Don't have an account? Sign Up" : "Already have an account? Sign In"}
              </button>
            </div>
          );
        }

        return (
           <div className="flex flex-col items-center justify-center h-[70vh] px-4 text-center">
            <div className="relative group cursor-pointer w-24 h-24 mb-4">
              <input 
                type="file" 
                accept="image/*" 
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10" 
                onChange={async (e) => {
                  const file = e.target.files?.[0];
                  if (file) {
                    const reader = new FileReader();
                    reader.onloadend = async () => {
                      const base64String = reader.result as string;
                      try {
                        const { updateProfile } = await import('firebase/auth');
                        await updateProfile(user, { photoURL: base64String });
                        setUser({ ...user, photoURL: base64String } as any);
                      } catch (err) {
                        alert("Failed to update profile picture. The image might be too large.");
                        console.error(err);
                      }
                    };
                    // Downscale the image to keep base64 small
                    const img = new Image();
                    img.onload = () => {
                      const canvas = document.createElement('canvas');
                      const MAX_WIDTH = 200;
                      const MAX_HEIGHT = 200;
                      let width = img.width;
                      let height = img.height;
                      if (width > height) {
                        if (width > MAX_WIDTH) {
                          height *= MAX_WIDTH / width;
                          width = MAX_WIDTH;
                        }
                      } else {
                        if (height > MAX_HEIGHT) {
                          width *= MAX_HEIGHT / height;
                          height = MAX_HEIGHT;
                        }
                      }
                      canvas.width = width;
                      canvas.height = height;
                      const ctx = canvas.getContext('2d');
                      ctx?.drawImage(img, 0, 0, width, height);
                      const dataUrl = canvas.toDataURL('image/jpeg', 0.7);
                      try {
                        import('firebase/auth').then(({ updateProfile }) => {
                          updateProfile(user, { photoURL: dataUrl }).then(() => {
                            setUser({ ...user, photoURL: dataUrl } as any);
                          });
                        });
                      } catch (err) {
                        console.error(err);
                      }
                    };
                    img.src = URL.createObjectURL(file);
                  }
                }}
              />
              <div className="w-full h-full bg-gradient-to-tr from-brand-primary to-brand-secondary rounded-2xl flex items-center justify-center text-white font-bold text-3xl shadow-sm overflow-hidden border-2 border-transparent group-hover:border-brand-primary transition-all">
                {user.photoURL ? (
                  <img src={user.photoURL} alt="Profile" className="w-full h-full object-cover" />
                ) : (
                  user.email?.charAt(0).toUpperCase() || 'U'
                )}
              </div>
              <div className="absolute inset-0 bg-black/40 rounded-2xl flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                 <Sparkles className="text-white w-6 h-6" />
              </div>
            </div>
            <h2 className="text-xl font-bold text-text-dark mb-1">{user.email}</h2>
            <p className="text-gray-400 text-sm mb-6 italic">Store Rewards: {Math.floor(Math.random() * 1000)} pts</p>
            <div className="w-full max-w-sm space-y-2 text-left">
              {['My Orders', 'Addresses', 'Wishlist', 'Beauty Profile', 'Settings'].map(item => (
                <div 
                  key={item} 
                  onClick={() => {
                    setProfileSubView(item);
                  }} 
                  className="bg-white p-4 rounded-2xl border border-brand-muted shadow-sm text-sm font-bold text-text-main cursor-pointer hover:text-brand-primary transition-colors"
                >
                  {item}
                </div>
              ))}
              <div onClick={() => {
                signOut(auth);
                showToast("Signed out successfully");
              }} className="bg-[#FFF0F3] p-4 rounded-2xl border border-[#FDE2E7] shadow-sm text-sm font-bold text-[#F27D9A] cursor-pointer hover:bg-[#FDE2E7] transition-colors mt-4">
                Sign Out
              </div>
            </div>
          </div>
        );
      default:
        return <HomeView 
          onProductClick={setSelectedProduct} 
          onNavigate={(tab) => {
            if (tab === 'search') setInitialSearchQuery('');
            setActiveTab(tab);
          }} 
          onCategoryClick={(catName) => {
            setInitialSearchQuery(catName);
            setActiveTab('search');
          }}
          categories={categories} 
          products={products} 
          banners={banners}
          onAddToCart={addToCart} 
          onTrackOrder={handleTrackOrder} 
        />;
    }
  };

  return (
    <div className="min-h-screen bg-brand-light font-sans text-text-main selection:bg-brand-muted">
      <div className="mx-auto w-full max-w-md relative min-h-screen bg-white shadow-[0_8px_30px_rgb(0,0,0,0.04)] border border-brand-muted md:overflow-hidden md:rounded-[40px] md:my-8 md:min-h-[85vh]">
        
        {/* Render main view */}
        <div className="h-full w-full overflow-y-auto no-scrollbar">
          {renderView()}
        </div>

        {/* Bottom Nav Menu */}
        <NavMenu
          activeTab={activeTab}
          setActiveTab={(tab) => {
            setActiveTab(tab);
            setStartCheckout(false);
            if (tab === 'search') {
              setInitialSearchQuery('');
            }
          }}
          cartCount={cartCount}
        />

        {/* Product Modal Overlay */}
        <ProductModal
          product={selectedProduct}
          onClose={() => setSelectedProduct(null)}
          onAddToCart={addToCart}
          onBuyNow={(product) => {
            addToCart(product);
            setStartCheckout(true);
            setActiveTab('cart');
          }}
        />

        {/* Global Toast */}
        {toastMessage && (
          <div className="fixed bottom-24 left-1/2 -translate-x-1/2 z-[100] animate-in fade-in slide-in-from-bottom-4 duration-300">
            <div className="bg-gray-900 text-white text-sm font-bold px-6 py-3 rounded-full shadow-xl flex items-center gap-2 whitespace-nowrap">
              <Sparkles size={16} className="text-brand-primary" />
              {toastMessage}
            </div>
          </div>
        )}
        
        <TrackingModal 
          isOpen={isTrackModalOpen} 
          onClose={() => setIsTrackModalOpen(false)} 
          orders={orders} 
          initialOrderId={trackOrderIdToOpen}
        />
      </div>
    </div>
  );
}


