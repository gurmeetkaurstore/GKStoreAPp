import React, { useState } from "react";
import { Category, Product, ProductVariant, BannerSetting } from "../types";
import { Plus, Image as ImageIcon, X, Edit2, Trash2, Printer, Download, Eye, Truck } from "lucide-react";

interface AdminDashboardProps {
  categories: Category[];
  products: Product[];
  orders?: any[];
  banners?: BannerSetting[];
  onUpdateBanners?: (banners: BannerSetting[]) => void;
  onAddCategory: (cat: Category) => void;
  onUpdateCategory?: (cat: Category) => void;
  onDeleteCategory?: (id: string) => void;
  onAddProduct: (prod: Product) => void;
  onUpdateProduct: (prod: Product) => void;
  onDeleteProduct: (id: string) => void;
  onRestoreData?: () => void;
  onUpdateOrderStatus?: (orderId: string, status: string, trackingLink?: string, courierPartner?: string, trackingNumber?: string) => void;
}

export function AdminDashboard({ 
  categories, 
  products, 
  orders = [],
  banners,
  onUpdateBanners,
  onAddCategory, 
  onUpdateCategory, 
  onDeleteCategory,
  onAddProduct,
  onUpdateProduct,
  onDeleteProduct,
  onRestoreData,
  onUpdateOrderStatus
}: AdminDashboardProps) {
  const [activeTab, setActiveTab] = useState('overview');
  const [selectedOrder, setSelectedOrder] = useState<any | null>(null);
  
  // Tracking Link Modal
  const [editingTrackingOrder, setEditingTrackingOrder] = useState<any | null>(null);
  const [trackingLinkInput, setTrackingLinkInput] = useState('');
  const [trackingNumberInput, setTrackingNumberInput] = useState('');
  const [courierPartnerInput, setCourierPartnerInput] = useState('');
  
  // Category Modal State
  const [showCatModal, setShowCatModal] = useState(false);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [newCatName, setNewCatName] = useState('');
  const [newCatImage, setNewCatImage] = useState('');
  const [newCatParentId, setNewCatParentId] = useState('');

  // Product Modal State
  const [showProductModal, setShowProductModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [prodForm, setProdForm] = useState({
    name: '',
    brand: '',
    price: '',
    originalPrice: '',
    stockQuantity: '',
    category: '',
    image: '',
    images: [] as string[],
    description: '',
    weightInKg: '',
    variants: [] as ProductVariant[],
    isNew: false,
    isBestseller: false,
    isViral: false
  });

  // Banner State
  const [bannerForms, setBannerForms] = useState<BannerSetting[]>([{
    id: `b-1`,
    imageUrl: 'https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&q=80&w=1200',
    mobileImageUrl: 'https://images.unsplash.com/photo-1616683693504-3ea7e9ad6fec?auto=format&fit=crop&q=80&w=800',
    heading: 'Radiant You.',
    subheading: 'Discover the new viral K-beauty routine for glass skin.',
    saleText: 'Sale is live! Flat 50% Off on Bestsellers ✨'
  }]);

  // Initialize bannerForms when banners prop changes
  React.useEffect(() => {
    if (banners && banners.length > 0) {
      setBannerForms(banners);
    }
  }, [banners]);

  const handleBannerImageChange = (e: React.ChangeEvent<HTMLInputElement>, isMobile: boolean, index: number) => {
    if (e.target.files && e.target.files.length > 0) {
      const file = e.target.files[0];
      const reader = new FileReader();
      reader.onloadend = () => {
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement('canvas');
          let width = img.width;
          let height = img.height;
          
          const MAX_WIDTH = isMobile ? 800 : 1600;
          const MAX_HEIGHT = isMobile ? 1200 : 800;
          
          if (width > MAX_WIDTH) {
            height *= MAX_WIDTH / width;
            width = MAX_WIDTH;
          }
          
          if (height > MAX_HEIGHT) {
            width *= MAX_HEIGHT / height;
            height = MAX_HEIGHT;
          }
          
          canvas.width = width;
          canvas.height = height;
          
          const ctx = canvas.getContext('2d');
          ctx?.drawImage(img, 0, 0, width, height);
          
          const dataUrl = canvas.toDataURL('image/jpeg', 0.82);
          
          setBannerForms(prev => {
            const newForms = [...prev];
            newForms[index] = {
              ...newForms[index],
              [isMobile ? 'mobileImageUrl' : 'imageUrl']: dataUrl
            };
            return newForms;
          });
        };
        img.src = reader.result as string;
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveBanners = (e: React.FormEvent) => {
    e.preventDefault();
    if (onUpdateBanners) {
      onUpdateBanners(bannerForms);
    }
  };

  const openCatModal = () => {
    setEditingCategory(null);
    setNewCatName('');
    setNewCatImage('');
    setNewCatParentId('');
    setShowCatModal(true);
  };

  const openEditCatModal = (cat: Category) => {
    setEditingCategory(cat);
    setNewCatName(cat.name);
    setNewCatImage(cat.image || '');
    setNewCatParentId(cat.parentId || '');
    setShowCatModal(true);
  };

  const openProductModal = () => {
    setEditingProduct(null);
    setProdForm({ 
      name: '', brand: '', price: '', originalPrice: '', stockQuantity: '', category: categories[0]?.id || '', image: '', images: [], description: '', weightInKg: '', variants: [],
      isNew: false, isBestseller: false, isViral: false
    });
    setShowProductModal(true);
  };

  const openEditProductModal = (prod: Product) => {
    setEditingProduct(prod);
    setProdForm({ 
      name: prod.name, 
      brand: prod.brand, 
      price: prod.price.toString(), 
      originalPrice: prod.originalPrice?.toString() || '',
      stockQuantity: prod.stockQuantity?.toString() || '',
      category: prod.category, 
      image: prod.image, 
      images: prod.images || [],
      description: prod.description || '',
      weightInKg: prod.weightInKg?.toString() || '',
      variants: prod.variants || [],
      isNew: !!prod.isNew,
      isBestseller: !!prod.isBestseller,
      isViral: !!prod.isViral
    });
    setShowProductModal(true);
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const reader = new FileReader();
      reader.onloadend = () => {
        setNewCatImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleProductImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const files = Array.from(e.target.files) as File[];
      const newImages: string[] = [];
      let loadedCount = 0;

      files.forEach((file) => {
        const reader = new FileReader();
        reader.onloadend = () => {
          newImages.push(reader.result as string);
          loadedCount++;
          if (loadedCount === files.length) {
            setProdForm(prev => ({ 
              ...prev, 
              image: prev.image || newImages[0], 
              images: [...prev.images, ...newImages] 
            }));
          }
        };
        reader.readAsDataURL(file);
      });
    }
  };

  const handleSaveCategory = () => {
    if (newCatName) {
      if (editingCategory) {
        const payload: any = {
          ...editingCategory,
          name: newCatName,
        };
        if (newCatImage) payload.image = newCatImage;
        else delete payload.image;
        if (newCatParentId) payload.parentId = newCatParentId;
        else delete payload.parentId;
        onUpdateCategory?.(payload as Category);
      } else {
        const payload: any = {
          id: `c-${Date.now()}`,
          name: newCatName,
          icon: "✨"
        };
        if (newCatImage) payload.image = newCatImage;
        if (newCatParentId) payload.parentId = newCatParentId;
        onAddCategory(payload as Category);
      }
      setShowCatModal(false);
    }
  };

  const handleDeleteCat = (id: string) => {
    if (confirm('Are you sure you want to delete this category?')) {
      onDeleteCategory?.(id);
    }
  };

  const handleSaveProduct = () => {
    if (prodForm.name && prodForm.price && prodForm.category) {
      if (editingProduct) {
        const payload: any = {
          ...editingProduct,
          name: prodForm.name,
          brand: prodForm.brand,
          price: Number(prodForm.price),
          stockQuantity: prodForm.stockQuantity ? Number(prodForm.stockQuantity) : 0,
          category: prodForm.category,
          image: prodForm.image,
          images: prodForm.images,
          variants: prodForm.variants,
          description: prodForm.description,
          weightInKg: prodForm.weightInKg ? Number(prodForm.weightInKg) : undefined,
          isNew: prodForm.isNew,
          isBestseller: prodForm.isBestseller,
          isViral: prodForm.isViral
        };
        if (prodForm.originalPrice) {
          payload.originalPrice = Number(prodForm.originalPrice);
        } else {
          delete payload.originalPrice;
        }
        if (payload.weightInKg === undefined) {
          delete payload.weightInKg;
        }
        onUpdateProduct(payload as Product);
      } else {
        const payload: any = {
          id: `p-${Date.now()}`,
          name: prodForm.name,
          brand: prodForm.brand,
          price: Number(prodForm.price),
          stockQuantity: prodForm.stockQuantity ? Number(prodForm.stockQuantity) : 0,
          category: prodForm.category,
          image: prodForm.image || (prodForm.images?.[0] || "https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&q=80&w=400"),
          images: prodForm.images,
          variants: prodForm.variants,
          description: prodForm.description,
          weightInKg: prodForm.weightInKg ? Number(prodForm.weightInKg) : undefined,
          isNew: prodForm.isNew,
          isBestseller: prodForm.isBestseller,
          isViral: prodForm.isViral,
          rating: 0,
          reviews: 0
        };
        if (payload.weightInKg === undefined) {
          delete payload.weightInKg;
        }
        if (prodForm.originalPrice) {
          payload.originalPrice = Number(prodForm.originalPrice);
        }
        onAddProduct(payload as Product);
      }
      setShowProductModal(false);
    }
  };

  const handleDeleteProd = (id: string) => {
    if (confirm('Are you sure you want to delete this product?')) {
      onDeleteProduct(id);
    }
  };


  return (
    <div className="w-full min-h-screen bg-[#FFF8F9] text-[#4A3B3B] font-sans flex overflow-x-hidden md:overflow-hidden relative">
      {/* Sidebar */}
      <aside className="w-64 bg-white border-r border-[#FDE2E7] hidden md:flex flex-col flex-shrink-0 h-screen sticky top-0">
        <div className="p-6">
          <div className="mb-8 flex justify-center">
            <img src="/logo.jpg" alt="Gurmeet Kaur Store" className="h-24 w-auto object-contain" />
          </div>
          <nav className="space-y-1 text-sm font-bold">
            <div onClick={() => setActiveTab('overview')} className={`flex items-center gap-3 px-4 py-3 rounded-xl cursor-pointer ${activeTab === 'overview' ? 'bg-[#FFF0F3] text-[#F27D9A]' : 'text-gray-400 hover:text-[#F27D9A] transition-colors'}`}>
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16"/></svg>
              Overview
            </div>
            <div onClick={() => setActiveTab('categories')} className={`flex items-center gap-3 px-4 py-3 rounded-xl cursor-pointer ${activeTab === 'categories' ? 'bg-[#FFF0F3] text-[#F27D9A]' : 'text-gray-400 hover:text-[#F27D9A] transition-colors'}`}>
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 002-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/></svg>
              Categories
            </div>
            <div onClick={() => setActiveTab('products')} className={`flex items-center gap-3 px-4 py-3 rounded-xl cursor-pointer ${activeTab === 'products' ? 'bg-[#FFF0F3] text-[#F27D9A]' : 'text-gray-400 hover:text-[#F27D9A] transition-colors'}`}>
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/></svg>
              Products
            </div>
            <div onClick={() => setActiveTab('orders')} className={`flex items-center gap-3 px-4 py-3 rounded-xl cursor-pointer ${activeTab === 'orders' ? 'bg-[#FFF0F3] text-[#F27D9A]' : 'text-gray-400 hover:text-[#F27D9A] transition-colors'}`}>
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/></svg>
              Orders
            </div>
            <div onClick={() => setActiveTab('banner')} className={`flex items-center gap-3 px-4 py-3 rounded-xl cursor-pointer ${activeTab === 'banner' ? 'bg-[#FFF0F3] text-[#F27D9A]' : 'text-gray-400 hover:text-[#F27D9A] transition-colors'}`}>
              <ImageIcon className="w-5 h-5" />
              Store Banner
            </div>
          </nav>
        </div>
        <div className="mt-auto p-6">
          <div className="bg-gradient-to-br from-[#FDE2E7] to-[#FFF5F7] p-4 rounded-2xl border border-white">
            <p className="text-xs font-bold text-[#F27D9A] uppercase tracking-wider mb-1">Pro Account</p>
            <p className="text-sm text-[#4A3B3B] opacity-70 mb-3">Manage 5 stores</p>
            <button className="w-full py-2 bg-white text-[#F27D9A] rounded-lg text-sm font-bold shadow-sm hover:scale-[1.02] transition-transform">Upgrade</button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col p-4 md:p-8 gap-6 overflow-y-auto h-screen">
        <header className="flex flex-col md:flex-row md:justify-between md:items-center gap-4">
          <div>
            <h1 className="text-2xl font-bold text-[#3D2B2B]">Beauty Dashboard</h1>
            <p className="text-gray-400 text-sm italic mt-1">Good morning, Aditi! Here's what's happening today.</p>
          </div>
          <div className="flex items-center justify-between md:justify-end gap-4">
            <div className="relative flex-1 md:flex-none flex items-center gap-2">
              {onRestoreData && (
                <button 
                  onClick={onRestoreData} 
                  className="bg-white border border-[#FDE2E7] text-[#F27D9A] hover:bg-[#FFF0F3] px-4 py-2 rounded-full text-sm font-bold transition-colors hidden md:block"
                >
                  Restore Demo Data
                </button>
              )}
              <input type="text" placeholder="Search catalog..." className="bg-white border border-[#FDE2E7] rounded-full px-4 py-2 text-sm w-full md:w-64 focus:outline-none focus:ring-2 focus:ring-[#F27D9A]/20" />
            </div>
            <div className="w-10 h-10 rounded-full border-2 border-[#F27D9A] p-0.5 shrink-0">
              <div className="w-full h-full rounded-full bg-slate-200"></div>
            </div>
          </div>
        </header>

        {/* Mobile Navigation */}
        <nav className="flex md:hidden gap-2 overflow-x-auto no-scrollbar pb-2">
          <button 
            onClick={() => setActiveTab('overview')} 
            className={`px-4 py-2 rounded-full text-sm font-bold whitespace-nowrap shrink-0 transition-colors ${activeTab === 'overview' ? 'bg-[#F27D9A] text-white' : 'bg-white text-gray-500 border border-[#FDE2E7]'}`}
          >
            Overview
          </button>
          <button 
            onClick={() => setActiveTab('categories')} 
            className={`px-4 py-2 rounded-full text-sm font-bold whitespace-nowrap shrink-0 transition-colors ${activeTab === 'categories' ? 'bg-[#F27D9A] text-white' : 'bg-white text-gray-500 border border-[#FDE2E7]'}`}
          >
            Categories
          </button>
          <button 
            onClick={() => setActiveTab('products')} 
            className={`px-4 py-2 rounded-full text-sm font-bold whitespace-nowrap shrink-0 transition-colors ${activeTab === 'products' ? 'bg-[#F27D9A] text-white' : 'bg-white text-gray-500 border border-[#FDE2E7]'}`}
          >
            Products
          </button>
          <button 
            onClick={() => setActiveTab('orders')} 
            className={`px-4 py-2 rounded-full text-sm font-bold whitespace-nowrap shrink-0 transition-colors ${activeTab === 'orders' ? 'bg-[#F27D9A] text-white' : 'bg-white text-gray-500 border border-[#FDE2E7]'}`}
          >
            Orders
          </button>
          <button 
            onClick={() => setActiveTab('banner')} 
            className={`px-4 py-2 rounded-full text-sm font-bold whitespace-nowrap shrink-0 transition-colors ${activeTab === 'banner' ? 'bg-[#F27D9A] text-white' : 'bg-white text-gray-500 border border-[#FDE2E7]'}`}
          >
            Store Banner
          </button>
        </nav>

        {activeTab === 'overview' && (
          <>
            <section className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
              <div className="bg-white p-4 md:p-6 rounded-3xl border border-[#FDE2E7] shadow-sm">
                <p className="text-gray-400 text-[10px] md:text-xs font-bold uppercase tracking-wider mb-2">Total Revenue</p>
                <h3 className="text-xl md:text-2xl font-bold">₹8,42k</h3>
                <p className="text-green-500 text-[10px] md:text-xs mt-2 font-bold">↑ 12% vs last month</p>
              </div>
              <div className="bg-white p-4 md:p-6 rounded-3xl border border-[#FDE2E7] shadow-sm">
                <p className="text-gray-400 text-[10px] md:text-xs font-bold uppercase tracking-wider mb-2">Total Orders</p>
                <h3 className="text-xl md:text-2xl font-bold">1,248</h3>
                <p className="text-green-500 text-[10px] md:text-xs mt-2 font-bold">↑ 8.4% today</p>
              </div>
              <div className="bg-white p-4 md:p-6 rounded-3xl border border-[#FDE2E7] shadow-sm">
                <p className="text-gray-400 text-[10px] md:text-xs font-bold uppercase tracking-wider mb-2">Avg. Ticket</p>
                <h3 className="text-xl md:text-2xl font-bold">₹1,850</h3>
                <p className="text-gray-400 text-[10px] md:text-xs mt-2 italic">Stable performance</p>
              </div>
              <div className="bg-white p-4 md:p-6 rounded-3xl border border-[#FDE2E7] shadow-sm">
                <p className="text-gray-400 text-[10px] md:text-xs font-bold uppercase tracking-wider mb-2">Conversion</p>
                <h3 className="text-xl md:text-2xl font-bold">3.2%</h3>
                <p className="text-[#F27D9A] text-[10px] md:text-xs mt-2 font-bold">↑ New campaign live</p>
              </div>
            </section>

            <section className="flex flex-col xl:flex-row flex-1 gap-6 pb-20 md:pb-0">
              <div className="flex-[1.5] bg-white rounded-[32px] border border-[#FDE2E7] p-6 shadow-sm flex flex-col">
                <div className="flex justify-between items-center mb-8">
                  <h4 className="font-bold text-[#3D2B2B]">Sales Analytics</h4>
                  <div className="flex gap-2">
                    <span className="px-3 py-1 bg-[#FFF5F7] text-[#F27D9A] rounded-full text-xs font-bold shadow-sm">Daily</span>
                    <span className="px-3 py-1 text-gray-400 text-xs font-bold cursor-pointer">Monthly</span>
                  </div>
                </div>
                
                <div className="h-48 w-full flex items-end justify-between gap-1 md:gap-3 px-2 mb-8">
                  <div className="w-full bg-[#FDE2E7] rounded-t-lg h-[40%] hover:bg-[#F27D9A] transition-colors"></div>
                  <div className="w-full bg-[#FDE2E7] rounded-t-lg h-[65%] hover:bg-[#F27D9A] transition-colors"></div>
                  <div className="w-full bg-[#F27D9A] rounded-t-lg h-[85%] shadow-sm shadow-[#F27D9A]/20"></div>
                  <div className="w-full bg-[#FDE2E7] rounded-t-lg h-[50%] hover:bg-[#F27D9A] transition-colors"></div>
                  <div className="w-full bg-[#FDE2E7] rounded-t-lg h-[70%] hover:bg-[#F27D9A] transition-colors"></div>
                  <div className="w-full bg-[#F27D9A] rounded-t-lg h-[95%] shadow-sm shadow-[#F27D9A]/20"></div>
                  <div className="w-full bg-[#FDE2E7] rounded-t-lg h-[60%] hover:bg-[#F27D9A] transition-colors"></div>
                  <div className="w-full bg-[#FDE2E7] rounded-t-lg h-[55%] hover:bg-[#F27D9A] transition-colors"></div>
                  <div className="w-full bg-[#F27D9A] rounded-t-lg h-[75%] shadow-sm shadow-[#F27D9A]/20"></div>
                  <div className="w-full bg-[#FDE2E7] rounded-t-lg h-[45%] hover:bg-[#F27D9A] transition-colors"></div>
                </div>

                <div className="mt-auto">
                  <h4 className="font-bold text-[#3D2B2B] mb-4">Recent Inventory Updates</h4>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 bg-[#FFF5F7] rounded-2xl border border-white shadow-sm">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-lg shadow-sm">💄</div>
                        <div>
                          <p className="text-sm font-bold">Velvet Rose Lipstick</p>
                          <p className="text-[10px] font-bold text-gray-400 mt-0.5 tracking-wide">SKU: LIP-002 • 14 shades</p>
                        </div>
                      </div>
                      <span className="text-[10px] font-bold px-2 py-1 bg-green-100 text-green-600 rounded-lg">In Stock</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex-1 bg-[#2C2121] rounded-[40px] p-6 text-white overflow-hidden shadow-2xl border-[8px] border-[#3D2B2B] relative hidden md:block">
                <div className="flex justify-between items-center mb-6">
                  <p className="text-lg font-bold italic tracking-tight">Glow & Grace</p>
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/></svg>
                </div>
                
                <div className="w-full h-32 bg-gradient-to-br from-[#F27D9A] to-[#E5B6A0] rounded-3xl p-4 flex flex-col justify-end relative overflow-hidden mb-6 shadow-inner">
                  <div className="absolute -right-4 -top-4 w-24 h-24 bg-white/20 rounded-full blur-2xl"></div>
                  <p className="text-[10px] font-bold uppercase tracking-widest opacity-80 mb-1">K-Beauty Event</p>
                  <h2 className="text-xl font-bold leading-tight tracking-tight">Get the Viral<br/>Glass Skin Look</h2>
                </div>
              </div>
            </section>
          </>
        )}

        {activeTab === 'categories' && (
          <section className="flex flex-col gap-6 h-full pb-20 md:pb-0">
            <div className="flex justify-between items-center bg-white p-6 rounded-3xl border border-[#FDE2E7] shadow-sm">
              <h2 className="text-xl font-bold text-[#3D2B2B]">Categories ({categories.length})</h2>
              <button onClick={openCatModal} className="bg-[#F27D9A] text-white px-4 py-2.5 rounded-xl text-sm font-bold flex items-center gap-2 hover:bg-[#E06D8A] transition-colors">
                <Plus size={16} /> Add Category
              </button>
            </div>
            
            <div className="bg-white rounded-3xl border border-[#FDE2E7] shadow-sm overflow-hidden flex-1 overflow-y-auto">
              <table className="w-full text-left">
                <thead className="bg-[#FFF5F7] text-[#3D2B2B] text-xs uppercase">
                  <tr>
                    <th className="px-6 py-4 font-bold border-b border-[#FDE2E7]">Image/Icon</th>
                    <th className="px-6 py-4 font-bold border-b border-[#FDE2E7]">Category Name</th>
                    <th className="px-6 py-4 font-bold border-b border-[#FDE2E7]">Products</th>
                    <th className="px-6 py-4 font-bold border-b border-[#FDE2E7]">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#FDE2E7]">
                  {categories.slice().sort((a, b) => {
                    const aStr = a.parentId ? `${categories.find(c => c.id === a.parentId)?.name || ''}-${a.name}` : a.name;
                    const bStr = b.parentId ? `${categories.find(c => c.id === b.parentId)?.name || ''}-${b.name}` : b.name;
                    return aStr.localeCompare(bStr);
                  }).map((cat) => (
                    <tr key={cat.id} className="hover:bg-[#FFF5F7] transition-colors">
                      <td className="px-6 py-4">
                        <div className={`w-14 h-14 bg-[#FFF0F3] border border-[#FDE2E7] flex items-center justify-center overflow-hidden shrink-0 shadow-sm ${cat.parentId ? 'ml-8 rounded-full' : 'rounded-xl text-2xl'}`}>
                          {cat.image ? (
                            <img src={cat.image} className="w-full h-full object-cover" alt={cat.name} />
                          ) : (
                            cat.icon
                          )}
                        </div>
                      </td>
                      <td className="px-6 py-4 font-bold text-[#3D2B2B]">
                        <div className={`flex flex-col ${cat.parentId ? 'ml-8' : ''}`}>
                          <span>{cat.name}</span>
                          {cat.parentId && <span className="text-xs text-gray-400 font-normal">Subcategory of {categories.find(c => c.id === cat.parentId)?.name}</span>}
                        </div>
                      </td>
                      <td className="px-6 py-4 text-gray-400 text-sm font-medium">
                        {products.filter(p => p.category === cat.id).length} items
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <button onClick={() => openEditCatModal(cat)} className="text-[#F27D9A] hover:bg-[#FFF0F3] p-2 rounded-lg transition-colors">
                            <Edit2 size={16} />
                          </button>
                          <button onClick={() => handleDeleteCat(cat.id)} className="text-red-500 hover:bg-red-50 p-2 rounded-lg transition-colors">
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        )}

        {activeTab === 'products' && (
          <section className="flex flex-col gap-6 h-full pb-20 md:pb-0">
            <div className="flex justify-between items-center bg-white p-6 rounded-3xl border border-[#FDE2E7] shadow-sm">
              <h2 className="text-xl font-bold text-[#3D2B2B]">Products ({products.length})</h2>
              <button onClick={openProductModal} className="bg-[#F27D9A] text-white px-4 py-2.5 rounded-xl text-sm font-bold flex items-center gap-2 hover:bg-[#E06D8A] transition-colors">
                <Plus size={16} /> Add Product
              </button>
            </div>
            
            <div className="bg-white rounded-3xl border border-[#FDE2E7] shadow-sm overflow-hidden flex-1 overflow-y-auto">
              <table className="w-full text-left">
                <thead className="bg-[#FFF5F7] text-[#3D2B2B] text-xs uppercase">
                  <tr>
                    <th className="px-6 py-4 font-bold border-b border-[#FDE2E7]">Product</th>
                    <th className="px-6 py-4 font-bold border-b border-[#FDE2E7]">Category</th>
                    <th className="px-6 py-4 font-bold border-b border-[#FDE2E7]">Price</th>
                    <th className="px-6 py-4 font-bold border-b border-[#FDE2E7]">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#FDE2E7]">
                  {products.map((prod) => (
                    <tr key={prod.id} className="hover:bg-[#FFF5F7] transition-colors">
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-4">
                          <img src={prod.image} alt={prod.name} className="w-12 h-12 rounded-lg object-cover border border-[#FDE2E7]" />
                          <div>
                            <p className="font-bold text-[#3D2B2B]">{prod.name}</p>
                            <p className="text-xs text-gray-400">{prod.brand}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 font-medium text-[#4A3B3B]">
                        {categories.find(c => c.id === prod.category)?.name || prod.category}
                      </td>
                      <td className="px-6 py-4 font-bold text-[#F27D9A]">₹{prod.price}</td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <button onClick={() => openEditProductModal(prod)} className="text-[#F27D9A] hover:bg-[#FFF0F3] p-2 rounded-lg transition-colors">
                            <Edit2 size={16} />
                          </button>
                          <button onClick={() => handleDeleteProd(prod.id)} className="text-red-500 hover:bg-red-50 p-2 rounded-lg transition-colors">
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        )}
        {activeTab === 'orders' && (
          <section className="flex flex-col gap-6 h-full pb-20 md:pb-0">
            <div className="flex justify-between items-center bg-white p-6 rounded-3xl border border-[#FDE2E7] shadow-sm">
              <h2 className="text-xl font-bold text-[#3D2B2B]">Orders ({orders?.length || 0})</h2>
            </div>
            
            <div className="bg-white rounded-3xl border border-[#FDE2E7] shadow-sm overflow-hidden flex-1 overflow-y-auto">
              <table className="w-full text-left">
                <thead className="bg-[#FFF5F7] text-[#3D2B2B] text-xs uppercase">
                  <tr>
                    <th className="px-6 py-4 font-bold border-b border-[#FDE2E7]">Order ID</th>
                    <th className="px-6 py-4 font-bold border-b border-[#FDE2E7]">Customer</th>
                    <th className="px-6 py-4 font-bold border-b border-[#FDE2E7]">Date</th>
                    <th className="px-6 py-4 font-bold border-b border-[#FDE2E7]">Total</th>
                    <th className="px-6 py-4 font-bold border-b border-[#FDE2E7]">Status</th>
                    <th className="px-6 py-4 font-bold border-b border-[#FDE2E7]">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#FDE2E7]">
                  {(orders || []).sort((a,b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()).map((order) => (
                    <tr key={order.id} className="hover:bg-[#FFF5F7] transition-colors">
                      <td className="px-6 py-4">
                        <span className="font-mono text-xs font-bold text-[#3D2B2B]">{order.id.slice(0, 8)}...</span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex flex-col">
                          <span className="text-sm font-bold text-[#3D2B2B]">
                            {order.customerName || order.userEmail || 'Guest'}
                          </span>
                          {order.customerName && order.userEmail && (
                            <span className="text-xs text-[#4A3B3B]">{order.userEmail}</span>
                          )}
                          {order.customerPhone && (
                            <span className="text-xs text-[#4A3B3B]">{order.customerPhone}</span>
                          )}
                        </div>
                      </td>
                      <td className="px-6 py-4 text-sm font-medium text-[#4A3B3B]">
                        {new Date(order.createdAt).toLocaleDateString()}
                      </td>
                      <td className="px-6 py-4 font-bold text-[#F27D9A]">₹{order.total.toFixed(2)}</td>
                      <td className="px-6 py-4">
                        <select 
                          value={order.status} 
                          onChange={(e) => onUpdateOrderStatus?.(order.id, e.target.value)}
                          className={`text-xs font-bold px-3 py-1.5 rounded-full border border-transparent focus:outline-none focus:ring-2 focus:ring-[#F27D9A]/50 ${
                            order.status === 'delivered' ? 'bg-green-100 text-green-700' :
                            order.status === 'shipped' ? 'bg-blue-100 text-blue-700' :
                            order.status === 'processing' ? 'bg-yellow-100 text-yellow-700' :
                            order.status === 'cancelled' ? 'bg-red-100 text-red-700' :
                            'bg-gray-100 text-gray-700'
                          }`}
                        >
                          <option value="pending">Pending</option>
                          <option value="processing">Processing</option>
                          <option value="shipped">Shipped</option>
                          <option value="delivered">Delivered</option>
                          <option value="cancelled">Cancelled</option>
                        </select>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <button onClick={() => setSelectedOrder(order)} className="text-[#3D2B2B] hover:bg-[#FFF0F3] p-2 rounded-lg transition-colors tooltip relative group">
                            <Eye size={16} />
                            <span className="absolute hidden group-hover:block -top-8 right-0 bg-[#3D2B2B] text-white text-xs px-2 py-1 rounded whitespace-nowrap">View Invoice</span>
                          </button>
                          <button onClick={() => {
                            setEditingTrackingOrder(order);
                            setTrackingLinkInput(order.trackingLink || "");
                            setTrackingNumberInput(order.trackingNumber || "");
                            setCourierPartnerInput(order.courierPartner || "");
                          }} className="text-[#3D2B2B] hover:bg-[#FFF0F3] p-2 rounded-lg transition-colors tooltip relative group">
                            <Truck size={16} />
                            <span className="absolute hidden group-hover:block -top-8 right-0 bg-[#3D2B2B] text-white text-xs px-2 py-1 rounded whitespace-nowrap">Edit Tracking</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                  {orders?.length === 0 && (
                    <tr>
                      <td colSpan={6} className="px-6 py-8 text-center text-gray-400 font-medium">No orders found.</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </section>
        )}

        {activeTab === 'banner' && (
          <section className="flex flex-col gap-6 h-full pb-20 md:pb-0 max-w-3xl">
            <div className="bg-white p-6 rounded-3xl border border-[#FDE2E7] shadow-sm">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-bold text-[#3D2B2B]">Home Page Banners</h2>
                <button type="button" onClick={() => setBannerForms([...bannerForms, { id: `b-${Date.now()}`, imageUrl: '', mobileImageUrl: '', heading: '', subheading: '', saleText: '' }])} className="bg-[#FFF0F3] text-[#F27D9A] px-4 py-2 rounded-xl text-sm font-bold hover:bg-[#FDE2E7] transition-colors flex items-center gap-2">
                   <Plus size={16} /> Add Banner
                </button>
              </div>
              <form onSubmit={handleSaveBanners} className="space-y-8">
                {bannerForms.map((bannerForm, index) => (
                  <div key={bannerForm.id} className="border border-[#FDE2E7] p-4 rounded-2xl relative space-y-6">
                    <div className="absolute top-4 right-4 z-20">
                      <button type="button" onClick={() => setBannerForms(bannerForms.filter((_, i) => i !== index))} className="text-red-400 hover:text-red-500 bg-red-50 p-2 rounded-full">
                        <Trash2 size={16} />
                      </button>
                    </div>
                <div>
                  <label className="block text-sm font-bold text-[#3D2B2B] mb-2">Desktop Image URL</label>
                  <div className="relative group w-full h-32 bg-[#FFF8F9] rounded-2xl border-2 border-dashed border-[#FDE2E7] hover:border-[#F27D9A] transition-colors flex flex-col items-center justify-center overflow-hidden mb-2">
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => handleBannerImageChange(e, false, index)}
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                    />
                    {bannerForm.imageUrl ? (
                      <img src={bannerForm.imageUrl} alt="Preview" className="w-full h-full object-cover rounded-xl" />
                    ) : (
                      <>
                        <ImageIcon className="text-[#F27D9A] mb-2 opacity-60 group-hover:opacity-100 transition-opacity" size={24} />
                        <span className="text-sm font-bold text-gray-400 group-hover:text-[#F27D9A] transition-colors">Click to upload</span>
                      </>
                    )}
                  </div>
                  <input
                    type="text"
                    value={bannerForm.imageUrl}
                    onChange={(e) => { const newForms = [...bannerForms]; newForms[index] = { ...newForms[index], imageUrl: e.target.value }; setBannerForms(newForms); }}
                    className="w-full px-4 py-3 rounded-xl border border-[#FDE2E7] bg-[#FFF8F9] focus:outline-none focus:ring-2 focus:ring-[#F27D9A]/50 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-sm font-bold text-[#3D2B2B] mb-2">Mobile Image URL</label>
                  <div className="relative group w-full h-32 bg-[#FFF8F9] rounded-2xl border-2 border-dashed border-[#FDE2E7] hover:border-[#F27D9A] transition-colors flex flex-col items-center justify-center overflow-hidden mb-2">
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => handleBannerImageChange(e, true, index)}
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                    />
                    {bannerForm.mobileImageUrl ? (
                      <img src={bannerForm.mobileImageUrl} alt="Preview" className="w-full h-full object-cover rounded-xl" />
                    ) : (
                      <>
                        <ImageIcon className="text-[#F27D9A] mb-2 opacity-60 group-hover:opacity-100 transition-opacity" size={24} />
                        <span className="text-sm font-bold text-gray-400 group-hover:text-[#F27D9A] transition-colors">Click to upload</span>
                      </>
                    )}
                  </div>
                  <input
                    type="text"
                    value={bannerForm.mobileImageUrl}
                    onChange={(e) => { const newForms = [...bannerForms]; newForms[index] = { ...newForms[index], mobileImageUrl: e.target.value }; setBannerForms(newForms); }}
                    className="w-full px-4 py-3 rounded-xl border border-[#FDE2E7] bg-[#FFF8F9] focus:outline-none focus:ring-2 focus:ring-[#F27D9A]/50 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-sm font-bold text-[#3D2B2B] mb-2">Heading</label>
                  <input
                    type="text"
                    value={bannerForm.heading}
                    onChange={(e) => { const newForms = [...bannerForms]; newForms[index] = { ...newForms[index], heading: e.target.value }; setBannerForms(newForms); }}
                    className="w-full px-4 py-3 rounded-xl border border-[#FDE2E7] bg-[#FFF8F9] focus:outline-none focus:ring-2 focus:ring-[#F27D9A]/50 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-sm font-bold text-[#3D2B2B] mb-2">Subheading</label>
                  <input
                    type="text"
                    value={bannerForm.subheading}
                    onChange={(e) => { const newForms = [...bannerForms]; newForms[index] = { ...newForms[index], subheading: e.target.value }; setBannerForms(newForms); }}
                    className="w-full px-4 py-3 rounded-xl border border-[#FDE2E7] bg-[#FFF8F9] focus:outline-none focus:ring-2 focus:ring-[#F27D9A]/50 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-sm font-bold text-[#3D2B2B] mb-2">Sale Banner Text</label>
                  <input
                    type="text"
                    value={bannerForm.saleText}
                    onChange={(e) => { const newForms = [...bannerForms]; newForms[index] = { ...newForms[index], saleText: e.target.value }; setBannerForms(newForms); }}
                    className="w-full px-4 py-3 rounded-xl border border-[#FDE2E7] bg-[#FFF8F9] focus:outline-none focus:ring-2 focus:ring-[#F27D9A]/50 text-sm"
                  />
                </div>
                </div>
                ))}
                
                <button type="button" onClick={() => setBannerForms([...bannerForms, { id: `b-${Date.now()}`, imageUrl: '', mobileImageUrl: '', heading: '', subheading: '', saleText: '' }])} className="w-full bg-[#FFF8F9] text-[#F27D9A] border-2 border-dashed border-[#FDE2E7] hover:border-[#F27D9A] py-4 rounded-2xl text-sm font-bold transition-colors flex items-center justify-center gap-2 mb-4">
                  <Plus size={20} /> Add Another Banner
                </button>

                <button type="submit" className="bg-[#F27D9A] text-white px-6 py-3 rounded-xl text-sm font-bold hover:bg-[#E06D8A] transition-colors w-full">
                  Save All Banners
                </button>
              </form>
            </div>
          </section>
        )}
      </main>

      {/* Add/Edit Category Modal */}
      {showCatModal && (
        <div className="fixed inset-0 z-50 flex justify-center items-center bg-[#4A3B3B]/40 backdrop-blur-sm p-4">
          <div className="bg-white w-full max-w-md rounded-3xl p-6 shadow-2xl border border-[#FDE2E7] relative">
            <button onClick={() => setShowCatModal(false)} className="absolute top-4 right-4 text-gray-400 hover:text-[#3D2B2B]">
              <X size={20} />
            </button>
            <h2 className="text-xl font-bold text-[#3D2B2B] mb-6 tracking-tight">{editingCategory ? 'Edit Category' : 'Add New Category'}</h2>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-bold text-[#3D2B2B] mb-2">Category Name</label>
                <input
                  type="text"
                  value={newCatName}
                  onChange={(e) => setNewCatName(e.target.value)}
                  placeholder="e.g. Organic Beauty"
                  className="w-full px-4 py-3 rounded-xl border border-[#FDE2E7] bg-[#FFF8F9] focus:outline-none focus:ring-2 focus:ring-[#F27D9A]/50 text-sm font-medium text-[#4A3B3B]"
                />
              </div>

              <div>
                <label className="block text-sm font-bold text-[#3D2B2B] mb-2">Parent Category (Optional)</label>
                <select
                  value={newCatParentId}
                  onChange={(e) => setNewCatParentId(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border border-[#FDE2E7] bg-[#FFF8F9] focus:outline-none focus:ring-2 focus:ring-[#F27D9A]/50 text-sm font-medium text-[#4A3B3B]"
                >
                  <option value="">None (Top Level)</option>
                  {categories.filter(c => c.id !== editingCategory?.id && !c.parentId).map(c => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-bold text-[#3D2B2B] mb-2">Category Image</label>
                <div className="w-full h-32 rounded-xl border-2 border-dashed border-[#FDE2E7] hover:border-[#F27D9A] bg-[#FFF8F9] flex flex-col items-center justify-center relative overflow-hidden group cursor-pointer transition-colors">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleImageChange}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                  />
                  {newCatImage ? (
                    <img src={newCatImage} alt="Preview" className="w-full h-full object-cover" />
                  ) : (
                    <>
                      <ImageIcon className="text-[#F27D9A] mb-2 opacity-60 group-hover:opacity-100 transition-opacity" size={24} />
                      <span className="text-sm font-bold text-gray-400 group-hover:text-[#F27D9A] transition-colors">Click to upload image</span>
                    </>
                  )}
                </div>
              </div>
              
              <button
                onClick={handleSaveCategory}
                disabled={!newCatName}
                className="w-full mt-4 bg-[#F27D9A] hover:bg-[#E06D8A] text-white font-bold py-3.5 rounded-xl disabled:opacity-50 disabled:hover:bg-[#F27D9A] transition-colors shadow-sm"
              >
                Save Category
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add/Edit Product Modal */}
      {showProductModal && (
        <div className="fixed inset-0 z-50 flex justify-center items-center bg-[#4A3B3B]/40 backdrop-blur-sm p-4">
          <div className="bg-white w-full max-w-md max-h-[90vh] overflow-y-auto rounded-3xl p-6 shadow-2xl border border-[#FDE2E7] relative">
            <button onClick={() => setShowProductModal(false)} className="absolute top-4 right-4 text-gray-400 hover:text-[#3D2B2B]">
              <X size={20} />
            </button>
            <h2 className="text-xl font-bold text-[#3D2B2B] mb-6 tracking-tight">{editingProduct ? 'Edit Product' : 'Add New Product'}</h2>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-bold text-[#3D2B2B] mb-2">Product Name</label>
                <input
                  type="text"
                  value={prodForm.name}
                  onChange={(e) => setProdForm({...prodForm, name: e.target.value})}
                  placeholder="e.g. Vitamin C Serum"
                  className="w-full px-4 py-3 rounded-xl border border-[#FDE2E7] bg-[#FFF8F9] focus:outline-none focus:ring-2 focus:ring-[#F27D9A]/50 text-sm font-medium text-[#4A3B3B]"
                />
              </div>

              <div>
                <label className="block text-sm font-bold text-[#3D2B2B] mb-2">Brand</label>
                <input
                  type="text"
                  value={prodForm.brand}
                  onChange={(e) => setProdForm({...prodForm, brand: e.target.value})}
                  placeholder="e.g. Glow & Co"
                  className="w-full px-4 py-3 rounded-xl border border-[#FDE2E7] bg-[#FFF8F9] focus:outline-none focus:ring-2 focus:ring-[#F27D9A]/50 text-sm font-medium text-[#4A3B3B]"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-bold text-[#3D2B2B] mb-2">Price (₹)</label>
                  <input
                    type="number"
                    value={prodForm.price}
                    onChange={(e) => setProdForm({...prodForm, price: e.target.value})}
                    placeholder="899"
                    className="w-full px-4 py-3 rounded-xl border border-[#FDE2E7] bg-[#FFF8F9] focus:outline-none focus:ring-2 focus:ring-[#F27D9A]/50 text-sm font-medium text-[#4A3B3B]"
                  />
                </div>
                <div>
                  <label className="block text-sm font-bold text-[#3D2B2B] mb-2">Original Price</label>
                  <input
                    type="number"
                    value={prodForm.originalPrice}
                    onChange={(e) => setProdForm({...prodForm, originalPrice: e.target.value})}
                    placeholder="1299"
                    className="w-full px-4 py-3 rounded-xl border border-[#FDE2E7] bg-[#FFF8F9] focus:outline-none focus:ring-2 focus:ring-[#F27D9A]/50 text-sm font-medium text-[#4A3B3B]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-bold text-[#3D2B2B] mb-2">Category</label>
                  <select
                    value={prodForm.category}
                    onChange={(e) => setProdForm({...prodForm, category: e.target.value})}
                    className="w-full px-4 py-3 rounded-xl border border-[#FDE2E7] bg-[#FFF8F9] focus:outline-none focus:ring-2 focus:ring-[#F27D9A]/50 text-sm font-medium text-[#4A3B3B]"
                  >
                    <option value="" disabled>Select a category</option>
                    {categories.map(cat => (
                      <option key={cat.id} value={cat.id}>{cat.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-bold text-[#3D2B2B] mb-2">Stock Quantity</label>
                  <input
                    type="number"
                    value={prodForm.stockQuantity}
                    onChange={(e) => setProdForm({...prodForm, stockQuantity: e.target.value})}
                    placeholder="100"
                    className="w-full px-4 py-3 rounded-xl border border-[#FDE2E7] bg-[#FFF8F9] focus:outline-none focus:ring-2 focus:ring-[#F27D9A]/50 text-sm font-medium text-[#4A3B3B]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-bold text-[#3D2B2B] mb-2">Homepage Sections</label>
                <div className="flex flex-col gap-2">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input 
                      type="checkbox" 
                      checked={prodForm.isNew} 
                      onChange={(e) => setProdForm({...prodForm, isNew: e.target.checked})}
                      className="w-4 h-4 text-[#F27D9A] rounded border-[#FDE2E7] focus:ring-[#F27D9A]"
                    />
                    <span className="text-sm font-medium text-[#4A3B3B]">New Arrivals</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input 
                      type="checkbox" 
                      checked={prodForm.isBestseller} 
                      onChange={(e) => setProdForm({...prodForm, isBestseller: e.target.checked})}
                      className="w-4 h-4 text-[#F27D9A] rounded border-[#FDE2E7] focus:ring-[#F27D9A]"
                    />
                    <span className="text-sm font-medium text-[#4A3B3B]">Bestsellers</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input 
                      type="checkbox" 
                      checked={prodForm.isViral} 
                      onChange={(e) => setProdForm({...prodForm, isViral: e.target.checked})}
                      className="w-4 h-4 text-[#F27D9A] rounded border-[#FDE2E7] focus:ring-[#F27D9A]"
                    />
                    <span className="text-sm font-medium text-[#4A3B3B]">Trending Now</span>
                  </label>
                </div>
              </div>

              <div>
                <label className="block text-sm font-bold text-[#3D2B2B] mb-2">Description</label>
                <textarea
                  value={prodForm.description}
                  onChange={(e) => setProdForm({...prodForm, description: e.target.value})}
                  placeholder="Product description..."
                  rows={3}
                  className="w-full px-4 py-3 rounded-xl border border-[#FDE2E7] bg-[#FFF8F9] focus:outline-none focus:ring-2 focus:ring-[#F27D9A]/50 text-sm font-medium text-[#4A3B3B] resize-none"
                />
              </div>

              <div>
                <label className="block text-sm font-bold text-[#3D2B2B] mb-2">Weight (kg)</label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  value={prodForm.weightInKg}
                  onChange={(e) => setProdForm({...prodForm, weightInKg: e.target.value})}
                  placeholder="1.5"
                  className="w-full px-4 py-3 rounded-xl border border-[#FDE2E7] bg-[#FFF8F9] focus:outline-none focus:ring-2 focus:ring-[#F27D9A]/50 text-sm font-medium text-[#4A3B3B]"
                />
              </div>

              <div>
                <label className="block text-sm font-bold text-[#3D2B2B] mb-2">Product Images</label>
                <div className="w-full h-32 rounded-xl border-2 border-dashed border-[#FDE2E7] hover:border-[#F27D9A] bg-[#FFF8F9] flex flex-col items-center justify-center relative overflow-hidden group cursor-pointer transition-colors">
                  <input
                    type="file"
                    accept="image/*"
                    multiple
                    onChange={handleProductImageChange}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                  />
                  {prodForm.images.length > 0 ? (
                    <div className="flex gap-2 p-2 overflow-x-auto w-full h-full">
                      {prodForm.images.map((img, idx) => (
                        <img key={idx} src={img} alt="Preview" className="w-20 h-20 object-cover rounded-lg border border-[#FDE2E7] shrink-0" />
                      ))}
                    </div>
                  ) : (
                    <>
                      <ImageIcon className="text-[#F27D9A] mb-2 opacity-60 group-hover:opacity-100 transition-opacity" size={24} />
                      <span className="text-sm font-bold text-gray-400 group-hover:text-[#F27D9A] transition-colors">Click to upload multiple images</span>
                    </>
                  )}
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="block text-sm font-bold text-[#3D2B2B]">Product Variants</label>
                  <button 
                    type="button"
                    onClick={() => {
                      setProdForm(prev => ({
                        ...prev,
                        variants: [...prev.variants, { id: `v-${Date.now()}`, weight: '', price: Number(prev.price) || 0, stockQuantity: 0, color: '' }]
                      }))
                    }}
                    className="text-xs font-bold text-white bg-[#F27D9A] hover:bg-[#E06D8A] px-3 py-1 rounded-lg transition-colors"
                  >
                    + Add Variant
                  </button>
                </div>
                {prodForm.variants.map((v, i) => (
                  <div key={v.id} className="bg-white p-3 rounded-xl border border-[#FDE2E7] mb-3 shadow-sm relative">
                    <button 
                      type="button" 
                      onClick={() => setProdForm(p => ({ ...p, variants: p.variants.filter((_, idx) => idx !== i) }))}
                      className="absolute top-2 right-2 text-red-400 hover:text-red-600"
                    >
                      <X size={16} />
                    </button>
                    <div className="grid grid-cols-2 gap-3 mt-1">
                      <div>
                        <label className="text-xs font-bold text-[#3D2B2B] mb-1 block">Weight / Size</label>
                        <input type="text" value={v.weight} onChange={e => {
                          const newV = [...prodForm.variants];
                          newV[i].weight = e.target.value;
                          setProdForm({...prodForm, variants: newV});
                        }} className="w-full px-3 py-2 rounded-lg border border-[#FDE2E7] text-xs" placeholder="e.g. 50g, XL" />
                      </div>
                      <div>
                        <label className="text-xs font-bold text-[#3D2B2B] mb-1 block">Color</label>
                        <input type="text" value={v.color} onChange={e => {
                          const newV = [...prodForm.variants];
                          newV[i].color = e.target.value;
                          setProdForm({...prodForm, variants: newV});
                        }} className="w-full px-3 py-2 rounded-lg border border-[#FDE2E7] text-xs" placeholder="e.g. Red, #ff0000" />
                      </div>
                      <div>
                        <label className="text-xs font-bold text-[#3D2B2B] mb-1 block">Price</label>
                        <input type="number" value={v.price} onChange={e => {
                          const newV = [...prodForm.variants];
                          newV[i].price = Number(e.target.value);
                          setProdForm({...prodForm, variants: newV});
                        }} className="w-full px-3 py-2 rounded-lg border border-[#FDE2E7] text-xs" placeholder="0" />
                      </div>
                      <div>
                        <label className="text-xs font-bold text-[#3D2B2B] mb-1 block">Stock Quantity</label>
                        <input type="number" value={v.stockQuantity} onChange={e => {
                          const newV = [...prodForm.variants];
                          newV[i].stockQuantity = Number(e.target.value);
                          setProdForm({...prodForm, variants: newV});
                        }} className="w-full px-3 py-2 rounded-lg border border-[#FDE2E7] text-xs" placeholder="0" />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              
              <button
                onClick={handleSaveProduct}
                disabled={!prodForm.name || !prodForm.price || !prodForm.category}
                className="w-full mt-4 bg-[#F27D9A] hover:bg-[#E06D8A] text-white font-bold py-3.5 rounded-xl disabled:opacity-50 disabled:hover:bg-[#F27D9A] transition-colors shadow-sm"
              >
                Save Product
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Invoice Modal */}
      {selectedOrder && (
        <div className="fixed inset-0 z-50 flex justify-center items-center bg-[#4A3B3B]/40 backdrop-blur-sm p-4 print:bg-white print:p-0">
          <div className="bg-white w-full max-w-2xl rounded-3xl p-6 md:p-8 shadow-2xl border border-[#FDE2E7] relative max-h-[90vh] overflow-y-auto print:max-w-none print:max-h-none print:shadow-none print:border-none print:overflow-visible text-sm">
            <button onClick={() => setSelectedOrder(null)} className="absolute top-4 right-4 text-gray-400 hover:text-[#3D2B2B] print:hidden">
              <X size={16} />
            </button>
            <div className="flex justify-between items-start mb-6 border-b border-[#FDE2E7] pb-4">
              <div>
                <img src="/logo.jpg" alt="Gurmeet Kaur Store" className="h-16 w-auto object-contain mb-1" />
                <p className="text-xs text-gray-400">Order Invoice</p>
              </div>
              <div className="text-right">
                <p className="font-bold text-[#3D2B2B] text-xs">Order #{selectedOrder.id.slice(0, 8).toUpperCase()}</p>
                <p className="text-xs text-gray-400">{new Date(selectedOrder.createdAt).toLocaleDateString()}</p>
              </div>
            </div>

            <div className="flex flex-col md:flex-row justify-between mb-6 gap-6">
              <div>
                <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1">Billed To</p>
                <p className="font-bold text-[#3D2B2B] text-xs">
                  {selectedOrder.customerName || selectedOrder.userEmail || 'Guest Customer'}
                </p>
                {selectedOrder.customerName && selectedOrder.userEmail && (
                  <p className="text-xs text-[#4A3B3B]">{selectedOrder.userEmail}</p>
                )}
                {selectedOrder.customerPhone && (
                  <p className="text-xs text-[#4A3B3B] mt-0.5">
                    <span className="font-semibold">Phone:</span> {selectedOrder.customerPhone}
                  </p>
                )}
                {selectedOrder.shippingAddress && (
                  <div className="text-xs text-[#4A3B3B] mt-0.5 space-y-0.5">
                    <p>{selectedOrder.shippingAddress.street}</p>
                    <p>{selectedOrder.shippingAddress.city}, {selectedOrder.shippingAddress.state} {selectedOrder.shippingAddress.zipCode}</p>
                  </div>
                )}
              </div>
              <div className="md:text-right">
                <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1">Status</p>
                <p className="font-bold text-[#F27D9A] capitalize text-xs mb-3">{selectedOrder.status}</p>

                <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1">Payment</p>
                <p className="font-bold text-[#3D2B2B] capitalize text-xs">{selectedOrder.paymentMethod || 'N/A'}</p>
                {selectedOrder.razorpayPaymentId && (
                  <p className="text-[10px] text-gray-400 mt-0.5 break-all max-w-[200px] ml-auto">
                    ID: {selectedOrder.razorpayPaymentId}
                  </p>
                )}
              </div>
            </div>

            <div className="mb-6">
              <table className="w-full text-left border-collapse text-xs">
                <thead className="bg-[#FFF5F7] text-[#3D2B2B] uppercase">
                  <tr>
                    <th className="p-2 font-bold text-[10px]">Item</th>
                    <th className="p-2 font-bold text-center text-[10px]">Qty</th>
                    <th className="p-2 font-bold text-right text-[10px]">Price</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#FDE2E7]">
                  {selectedOrder.items?.map((item: any, idx: number) => (
                    <tr key={idx}>
                      <td className="p-2">
                        <p className="font-bold text-[#3D2B2B]">{item.name}</p>
                        {item.variantId && <p className="text-[10px] text-gray-500">Variant: {item.variantId}</p>}
                      </td>
                      <td className="p-2 text-center">{item.quantity}</td>
                      <td className="p-2 text-right">₹{(item.price * item.quantity).toFixed(2)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="flex justify-end pt-4 border-t border-[#FDE2E7] text-xs">
              <div className="w-full md:w-1/2">
                <div className="flex justify-between items-center mb-1.5">
                  <span className="text-[#4A3B3B]">Subtotal</span>
                  <span className="font-medium">₹{(selectedOrder.subtotal ?? (selectedOrder.total - (selectedOrder.shippingCost ?? 0))).toFixed(2)}</span>
                </div>
                <div className="flex justify-between items-center mb-3 pb-3 border-b border-[#FDE2E7]">
                  <span className="text-[#4A3B3B]">Shipping</span>
                  <span className="font-medium">₹{(selectedOrder.shippingCost ?? (selectedOrder.total - (selectedOrder.subtotal ?? selectedOrder.total))).toFixed(2)}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-base font-bold text-[#3D2B2B]">Total</span>
                  <span className="text-lg font-bold text-[#F27D9A]">₹{selectedOrder.total.toFixed(2)}</span>
                </div>
              </div>
            </div>

            <div className="mt-10 flex gap-4 justify-end print:hidden">
              <button onClick={() => window.print()} className="bg-white border border-[#FDE2E7] text-[#3D2B2B] px-6 py-3 rounded-xl font-bold hover:bg-[#FFF5F7] transition-colors flex items-center gap-2">
                <Printer size={18} /> Print
              </button>
              <button onClick={() => window.print()} className="bg-[#F27D9A] text-white px-6 py-3 rounded-xl font-bold hover:bg-[#E06D8A] transition-colors flex items-center gap-2 shadow-sm">
                <Download size={18} /> Download
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit Tracking Modal */}
      {editingTrackingOrder && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-3xl w-full max-w-md p-6 shadow-xl relative">
            <button onClick={() => setEditingTrackingOrder(null)} className="absolute top-6 right-6 text-gray-400 hover:text-[#3D2B2B] transition-colors"><X size={20} /></button>
            <h2 className="text-xl font-bold text-[#3D2B2B] mb-6 tracking-tight flex items-center gap-2">
              <Truck className="text-[#F27D9A]" size={24} /> Edit Tracking Details
            </h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-bold text-[#3D2B2B] mb-2">Courier Partner</label>
                <input 
                  type="text" 
                  value={courierPartnerInput}
                  onChange={(e) => setCourierPartnerInput(e.target.value)}
                  placeholder="e.g. FedEx, Blue Dart" 
                  className="w-full px-4 py-3 rounded-xl border border-[#FDE2E7] bg-[#FFF5F7] focus:outline-none focus:ring-2 focus:ring-[#F27D9A]/50 text-sm font-medium"
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-[#3D2B2B] mb-2">Tracking Number</label>
                <input 
                  type="text" 
                  value={trackingNumberInput}
                  onChange={(e) => setTrackingNumberInput(e.target.value)}
                  placeholder="e.g. 1234567890" 
                  className="w-full px-4 py-3 rounded-xl border border-[#FDE2E7] bg-[#FFF5F7] focus:outline-none focus:ring-2 focus:ring-[#F27D9A]/50 text-sm font-medium"
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-[#3D2B2B] mb-2">Tracking URL</label>
                <input 
                  type="url" 
                  value={trackingLinkInput}
                  onChange={(e) => setTrackingLinkInput(e.target.value)}
                  placeholder="https://track.courier.com/..." 
                  className="w-full px-4 py-3 rounded-xl border border-[#FDE2E7] bg-[#FFF5F7] focus:outline-none focus:ring-2 focus:ring-[#F27D9A]/50 text-sm font-medium"
                />
                <p className="text-xs text-gray-400 mt-2">Enter the tracking link provided by the shipping carrier.</p>
              </div>
              <div className="flex justify-end gap-3 pt-4">
                <button type="button" onClick={() => setEditingTrackingOrder(null)} className="px-5 py-2.5 bg-[#FFF0F3] text-[#F27D9A] rounded-xl font-bold text-sm hover:bg-[#FDE2E7] transition-colors">Cancel</button>
                <button 
                  type="button" 
                  onClick={() => {
                    onUpdateOrderStatus?.(editingTrackingOrder.id, editingTrackingOrder.status, trackingLinkInput, courierPartnerInput, trackingNumberInput);
                    setEditingTrackingOrder(null);
                  }}
                  className="px-5 py-2.5 bg-[#F27D9A] text-white rounded-xl font-bold text-sm hover:bg-[#E06D8A] transition-colors shadow-sm"
                >
                  Save Link
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
