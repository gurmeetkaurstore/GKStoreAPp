import React from "react";
import { Home, Search, ShoppingBag, User, Sparkles } from "lucide-react";
import { cn } from "../utils";

interface NavMenuProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  cartCount: number;
}

export function NavMenu({ activeTab, setActiveTab, cartCount }: NavMenuProps) {
  const tabs = [
    { id: "home", icon: Home, label: "Home" },
    { id: "search", icon: Search, label: "Search" },
    { id: "ai", icon: Sparkles, label: "AI Match" },
    { id: "cart", icon: ShoppingBag, label: "Cart", badge: cartCount },
    { id: "profile", icon: User, label: "Profile" },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 flex justify-center pb-safe md:pb-0 md:absolute rounded-b-[40px] overflow-hidden">
      <div className="w-full max-w-md bg-white/90 backdrop-blur-2xl border-t border-brand-muted shadow-[0_-8px_30px_rgb(0,0,0,0.06)]">
        <div className="flex items-center justify-around px-2 pb-2 pt-3">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            const isAI = tab.id === "ai";

            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className="relative flex flex-col items-center justify-center w-14 gap-1"
              >
                <div
                  className={cn(
                    "relative flex items-center justify-center rounded-xl p-1.5 transition-all duration-300",
                    isActive && !isAI ? "text-brand-primary" : "text-gray-400",
                    isAI ? "bg-gradient-to-r from-brand-primary to-brand-secondary text-white shadow-lg shadow-brand-primary/20 -mt-4 w-12 h-12 rounded-[20px]" : ""
                  )}
                >
                  <Icon size={isAI ? 22 : 24} />
                  {tab.badge ? (
                    <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-text-dark text-[10px] font-bold text-white shadow-sm border-2 border-white">
                      {tab.badge}
                    </span>
                  ) : null}
                </div>
                {!isAI && (
                  <span
                    className={cn(
                      "text-[10px] font-bold transition-colors uppercase tracking-wider scale-90",
                      isActive ? "text-brand-primary" : "text-gray-400 font-medium"
                    )}
                  >
                    {tab.label}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
