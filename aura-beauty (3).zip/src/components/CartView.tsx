import React, { useState, useEffect } from "react";
import { CartItem } from "../types";
import { formatPrice } from "../utils";
import { motion } from "motion/react";
import { Minus, Plus, Trash2, ShoppingBag, ArrowLeft, CreditCard, Wallet, Banknote, MapPin } from "lucide-react";
import { collection, onSnapshot } from "firebase/firestore";
import { db } from "../firebase";

interface CartViewProps {
  items: CartItem[];
  updateQuantity: (id: string, qty: number) => void;
  removeItem: (id: string) => void;
  onCheckout?: (details: any) => void;
  onCancelCheckout?: () => void;
  startCheckout?: boolean;
  userId?: string;
}

export function CartView({ items, updateQuantity, removeItem, onCheckout, onCancelCheckout, startCheckout = false, userId }: CartViewProps) {
  const [showCheckout, setShowCheckout] = useState(startCheckout);
  const [savedAddresses, setSavedAddresses] = useState<any[]>([]);

  useEffect(() => {
    if (startCheckout) {
      setShowCheckout(true);
    }
  }, [startCheckout]);

  useEffect(() => {
    if (userId) {
      const addressesRef = collection(db, `users/${userId}/addresses`);
      const unsubscribe = onSnapshot(addressesRef, (snapshot) => {
        const addrs: any[] = [];
        snapshot.forEach((doc) => addrs.push({ id: doc.id, ...doc.data() }));
        setSavedAddresses(addrs);
      });
      return () => unsubscribe();
    }
  }, [userId]);

  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    address: '',
    city: '',
    state: '',
    zipCode: '',
    paymentMethod: 'card'
  });

  const subtotal = items.reduce((acc, item) => acc + item.price * item.quantity, 0);
  const totalWeightInKg = items.reduce((acc, item) => acc + (item.weightInKg || 1) * item.quantity, 0);
  const shipping = Math.ceil(totalWeightInKg) * 80;
  const total = subtotal + shipping;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (onCheckout) {
      onCheckout(formData);
    }
  };

  if (items.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-[70vh] px-4 text-center">
        <div className="w-20 h-20 bg-brand-soft border border-brand-muted rounded-[32px] flex items-center justify-center mb-4">
          <ShoppingBag className="text-brand-primary" size={32} />
        </div>
        <h2 className="text-xl font-bold text-text-dark mb-2 tracking-tight">Your Bag is Empty</h2>
        <p className="text-gray-400 text-sm max-w-xs italic">
          Looks like you haven't added any beauty essentials to your bag yet.
        </p>
      </div>
    );
  }

  if (showCheckout) {
    return (
      <div className="flex flex-col pb-32 pt-4 px-4 min-h-screen bg-brand-light">
        <div className="flex items-center gap-4 mb-6">
          <button onClick={() => { setShowCheckout(false); if(onCancelCheckout) onCancelCheckout(); }} className="w-10 h-10 rounded-full bg-white flex items-center justify-center text-gray-500 shadow-sm border border-brand-muted hover:text-brand-primary">
            <ArrowLeft size={20} />
          </button>
          <h2 className="text-2xl font-bold text-text-dark tracking-tight">Checkout</h2>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="bg-white p-6 rounded-[32px] shadow-sm border border-brand-muted">
            <h3 className="font-bold text-text-dark mb-4 tracking-tight text-lg">Contact Details</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-bold text-gray-500 mb-1">Full Name</label>
                <input required type="text" value={formData.name} onChange={(e) => setFormData({...formData, name: e.target.value})} className="w-full bg-brand-light border border-brand-muted rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand-primary/50" placeholder="Jane Doe" />
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-500 mb-1">Phone Number</label>
                <input required type="tel" value={formData.phone} onChange={(e) => setFormData({...formData, phone: e.target.value})} className="w-full bg-brand-light border border-brand-muted rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand-primary/50" placeholder="+91 98765 43210" />
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-[32px] shadow-sm border border-brand-muted">
            <h3 className="font-bold text-text-dark mb-4 tracking-tight text-lg">Shipping Address</h3>
            <div className="space-y-4">
              {savedAddresses.length > 0 && (
                <div>
                  <label className="block text-sm font-bold text-gray-500 mb-1">Use Saved Address</label>
                  <select 
                    className="w-full bg-brand-light border border-brand-muted rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand-primary/50"
                    onChange={(e) => {
                      const addr = savedAddresses.find(a => a.id === e.target.value);
                      if (addr) {
                        setFormData({
                          ...formData,
                          name: addr.name || formData.name,
                          phone: addr.phone || formData.phone,
                          address: addr.street || '',
                          city: addr.city || '',
                          state: addr.state || '',
                          zipCode: addr.zipCode || ''
                        });
                      }
                    }}
                  >
                    <option value="">Select an address...</option>
                    {savedAddresses.map(addr => (
                      <option key={addr.id} value={addr.id}>{addr.name} - {addr.street}, {addr.city}</option>
                    ))}
                  </select>
                </div>
              )}
              <div>
                <label className="block text-sm font-bold text-gray-500 mb-1">Street Address</label>
                <input required type="text" value={formData.address} onChange={(e) => setFormData({...formData, address: e.target.value})} className="w-full bg-brand-light border border-brand-muted rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand-primary/50" placeholder="123 Beauty Lane" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-bold text-gray-500 mb-1">City</label>
                  <input required type="text" value={formData.city} onChange={(e) => setFormData({...formData, city: e.target.value})} className="w-full bg-brand-light border border-brand-muted rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand-primary/50" placeholder="Mumbai" />
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-500 mb-1">Postal Code</label>
                  <input required type="text" value={formData.zipCode} onChange={(e) => setFormData({...formData, zipCode: e.target.value})} className="w-full bg-brand-light border border-brand-muted rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand-primary/50" placeholder="400001" />
                </div>
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-500 mb-1">State</label>
                <input required type="text" value={formData.state} onChange={(e) => setFormData({...formData, state: e.target.value})} className="w-full bg-brand-light border border-brand-muted rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-brand-primary/50" placeholder="Maharashtra" />
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-[32px] shadow-sm border border-brand-muted">
            <h3 className="font-bold text-text-dark mb-4 tracking-tight text-lg">Payment Method</h3>
            <div className="space-y-3">
              <label className={`flex items-center gap-4 p-4 rounded-2xl border cursor-pointer transition-colors ${formData.paymentMethod === 'card' ? 'border-brand-primary bg-brand-soft' : 'border-brand-muted bg-white'}`}>
                <input type="radio" value="card" checked={formData.paymentMethod === 'card'} onChange={(e) => setFormData({...formData, paymentMethod: e.target.value})} className="hidden" />
                <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center text-blue-500 shadow-sm"><CreditCard size={20} /></div>
                <div>
                  <p className="font-bold text-text-dark">Credit / Debit Card</p>
                  <p className="text-xs text-gray-400">Pay securely with card</p>
                </div>
              </label>
              
              <label className={`flex items-center gap-4 p-4 rounded-2xl border cursor-pointer transition-colors ${formData.paymentMethod === 'upi' ? 'border-brand-primary bg-brand-soft' : 'border-brand-muted bg-white'}`}>
                <input type="radio" value="upi" checked={formData.paymentMethod === 'upi'} onChange={(e) => setFormData({...formData, paymentMethod: e.target.value})} className="hidden" />
                <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center text-purple-500 shadow-sm"><Wallet size={20} /></div>
                <div>
                  <p className="font-bold text-text-dark">UPI</p>
                  <p className="text-xs text-gray-400">Google Pay, PhonePe, Paytm</p>
                </div>
              </label>

              <label className={`flex items-center gap-4 p-4 rounded-2xl border cursor-pointer transition-colors ${formData.paymentMethod === 'cod' ? 'border-brand-primary bg-brand-soft' : 'border-brand-muted bg-white'}`}>
                <input type="radio" value="cod" checked={formData.paymentMethod === 'cod'} onChange={(e) => setFormData({...formData, paymentMethod: e.target.value})} className="hidden" />
                <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center text-green-500 shadow-sm"><Banknote size={20} /></div>
                <div>
                  <p className="font-bold text-text-dark">Cash on Delivery</p>
                  <p className="text-xs text-gray-400">Pay when order arrives</p>
                </div>
              </label>
            </div>
          </div>

          <div className="bg-white p-6 rounded-[32px] shadow-sm border border-brand-muted flex flex-col gap-4">
             <div className="flex justify-between items-end">
              <span className="text-text-main font-bold uppercase tracking-wider text-xs">Total to Pay</span>
              <span className="text-2xl font-bold text-text-dark">{formatPrice(total)}</span>
            </div>
            <button type="submit" className="w-full bg-gradient-to-r from-brand-primary to-brand-secondary text-white rounded-2xl py-4 font-bold shadow-lg shadow-brand-primary/20 hover:opacity-90 active:scale-[0.98] transition-all">
              Confirm Order
            </button>
          </div>
        </form>
      </div>
    );
  }

  return (
    <div className="flex flex-col pb-32 pt-4 px-4 min-h-screen bg-brand-light">
      <h2 className="text-2xl font-bold text-text-dark mb-6 tracking-tight">Your Bag</h2>

      <div className="flex flex-col gap-4">
        {items.map((item) => (
          <motion.div
            layout
            key={item.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="flex gap-4 bg-white p-3 rounded-3xl shadow-sm border border-brand-muted"
          >
            <div className="w-24 h-24 bg-brand-light border border-brand-muted rounded-2xl overflow-hidden shrink-0">
              <img
                src={item.image}
                alt={item.name}
                className="w-full h-full object-cover"
              />
            </div>
            
            <div className="flex flex-1 flex-col justify-between py-1">
              <div>
                <h3 className="text-sm font-bold text-text-dark leading-tight line-clamp-2">
                  {item.name}
                </h3>
                <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mt-1">{item.brand}</p>
              </div>

              <div className="flex items-center justify-between mt-3">
                <span className="font-bold text-brand-primary">
                  {formatPrice(item.price)}
                </span>
                
                <div className="flex items-center gap-3 bg-brand-light border border-brand-muted rounded-xl px-2 py-1">
                  <button
                    onClick={() => updateQuantity(item.id, item.quantity - 1)}
                    className="w-6 h-6 flex items-center justify-center bg-white rounded-lg shadow-sm text-gray-600 hover:text-brand-primary disabled:opacity-50"
                  >
                    {item.quantity === 1 ? <Trash2 size={12} /> : <Minus size={12} />}
                  </button>
                  <span className="text-xs font-bold w-3 text-center">
                    {item.quantity}
                  </span>
                  <button
                    onClick={() => updateQuantity(item.id, item.quantity + 1)}
                    className="w-6 h-6 flex items-center justify-center bg-white rounded-lg shadow-sm text-gray-600 hover:text-brand-primary"
                  >
                    <Plus size={12} />
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="mt-8 bg-white rounded-[32px] p-6 shadow-sm border border-brand-muted">
        <h3 className="font-bold text-text-dark mb-4 text-lg">Order Summary</h3>
        <div className="space-y-4 text-sm text-gray-500">
          <div className="flex justify-between items-center">
            <span>Subtotal</span>
            <span className="text-text-main font-bold">{formatPrice(subtotal)}</span>
          </div>
          <div className="flex justify-between items-center">
            <span>Shipping</span>
            {shipping === 0 ? (
              <span className="text-green-500 font-bold px-3 py-1 bg-green-50 rounded-full text-xs">Free</span>
            ) : (
              <span className="text-text-main font-bold">{formatPrice(shipping)}</span>
            )}
          </div>
          <div className="border-t border-brand-muted pt-4 flex justify-between items-end">
            <span className="text-text-main font-bold uppercase tracking-wider text-xs">Total</span>
            <span className="text-2xl font-bold text-text-dark">{formatPrice(total)}</span>
          </div>
        </div>

        <button onClick={() => setShowCheckout(true)} className="w-full mt-6 bg-gradient-to-r from-brand-primary to-brand-secondary text-white rounded-2xl py-4 font-bold shadow-lg shadow-brand-primary/20 hover:opacity-90 active:scale-[0.98] transition-all">
          Checkout Securely
        </button>
      </div>
    </div>
  );
}
