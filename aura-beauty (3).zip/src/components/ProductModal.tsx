import React from "react";
import { Product } from "../types";
import { motion, AnimatePresence } from "motion/react";
import { X, Star, Heart, Share2, ShieldCheck, Truck } from "lucide-react";
import { formatPrice } from "../utils";

interface ProductModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (product: Product) => void;
  onBuyNow?: (product: Product) => void;
}

export function ProductModal({ product, onClose, onAddToCart, onBuyNow }: ProductModalProps) {
  const [selectedVariantId, setSelectedVariantId] = React.useState<string | null>(null);
  const [currentImageIndex, setCurrentImageIndex] = React.useState(0);

  React.useEffect(() => {
    setCurrentImageIndex(0);
    if (product?.variants?.length) {
      setSelectedVariantId(product.variants[0].id);
    } else {
      setSelectedVariantId(null);
    }
  }, [product]);

  const allImages = React.useMemo(() => {
    if (!product) return [];
    if (product.images && product.images.length > 0) {
      if (product.image && !product.images.includes(product.image)) {
        return [product.image, ...product.images];
      }
      return product.images;
    }
    return [product.image];
  }, [product]);

  if (!product) return null;

  const selectedVariant = product.variants?.find(v => v.id === selectedVariantId);
  const displayPrice = selectedVariant ? selectedVariant.price : product.price;

  const isOutOfStock = product.variants?.length 
    ? (selectedVariant ? selectedVariant.stockQuantity === 0 : product.variants.every(v => v.stockQuantity === 0))
    : (product.stockQuantity === 0);

  const getProductToAdd = (): Product => {
    if (selectedVariant) {
      let variantWeightInKg = product.weightInKg || 1;
      const weightStr = selectedVariant.weight.toLowerCase();
      const match = weightStr.match(/(\d+(?:\.\d+)?)\s*(kg|g|gm|ml|l|oz)/);
      if (match) {
        const val = parseFloat(match[1]);
        const unit = match[2];
        if (unit === 'g' || unit === 'gm' || unit === 'ml') {
          variantWeightInKg = val / 1000;
        } else if (unit === 'kg' || unit === 'l') {
          variantWeightInKg = val;
        } else if (unit === 'oz') {
          variantWeightInKg = val * 0.0283495;
        }
      } else {
        const fallbackVal = parseFloat(weightStr);
        if (!isNaN(fallbackVal)) {
          variantWeightInKg = fallbackVal > 100 ? fallbackVal / 1000 : fallbackVal;
        }
      }

      return {
        ...product,
        id: `${product.id}-${selectedVariant.id}`,
        price: selectedVariant.price,
        weightInKg: variantWeightInKg,
        name: `${product.name} - ${selectedVariant.weight} ${selectedVariant.color ? `(${selectedVariant.color})` : ''}`
      };
    }
    return product;
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[100] flex justify-center bg-black/40 backdrop-blur-sm md:items-center">
        <motion.div
          initial={{ y: "100%" }}
          animate={{ y: 0 }}
          exit={{ y: "100%" }}
          transition={{ type: "spring", damping: 25, stiffness: 200 }}
          className="relative mt-20 md:mt-0 flex h-full md:h-[85vh] w-full max-w-md flex-col overflow-hidden rounded-t-[32px] md:rounded-[32px] bg-white shadow-2xl pb-safe"
        >
          {/* Header Actions */}
          <div className="absolute top-4 right-4 z-10 flex gap-2">
            <button onClick={() => alert('Opening share options...')} className="flex h-10 w-10 items-center justify-center rounded-2xl bg-white border border-brand-muted shadow-sm text-text-main hover:text-brand-primary">
              <Share2 size={18} />
            </button>
            <button onClick={() => alert('Added to wishlist')} className="flex h-10 w-10 items-center justify-center rounded-2xl bg-white border border-brand-muted shadow-sm text-text-main hover:text-brand-primary">
              <Heart size={18} />
            </button>
            <button
              onClick={onClose}
              className="flex h-10 w-10 items-center justify-center rounded-2xl bg-white border border-brand-muted shadow-sm text-text-dark"
            >
              <X size={20} />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto no-scrollbar">
            {/* Image Gallery */}
            <div className="relative aspect-[4/5] w-full bg-brand-light border-b border-brand-muted rounded-b-[40px] group overflow-hidden">
              <img
                src={allImages[currentImageIndex]}
                alt={`${product.name} - ${currentImageIndex + 1}`}
                className="h-full w-full object-cover rounded-b-[40px] transition-opacity duration-300"
              />
              {allImages.length > 1 && (
                <>
                  <div className="absolute inset-x-0 bottom-4 flex justify-center gap-1.5 z-10">
                    {allImages.map((_, i) => (
                      <button
                        key={i}
                        onClick={(e) => {
                          e.stopPropagation();
                          setCurrentImageIndex(i);
                        }}
                        className={`h-1.5 rounded-full transition-all duration-300 ${i === currentImageIndex ? 'w-6 bg-brand-primary' : 'w-1.5 bg-brand-primary/30'}`}
                      />
                    ))}
                  </div>
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      setCurrentImageIndex(prev => prev === 0 ? allImages.length - 1 : prev - 1);
                    }}
                    className="absolute left-4 top-1/2 -translate-y-1/2 w-8 h-8 flex items-center justify-center bg-white/80 backdrop-blur-sm shadow-sm rounded-full text-brand-primary opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round"><polyline points="15 18 9 12 15 6"></polyline></svg>
                  </button>
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      setCurrentImageIndex(prev => prev === allImages.length - 1 ? 0 : prev + 1);
                    }}
                    className="absolute right-4 top-1/2 -translate-y-1/2 w-8 h-8 flex items-center justify-center bg-white/80 backdrop-blur-sm shadow-sm rounded-full text-brand-primary opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round"><polyline points="9 18 15 12 9 6"></polyline></svg>
                  </button>
                </>
              )}
            </div>

            <div className="p-6">
              <span className="mb-2 inline-block text-[10px] font-bold tracking-widest text-brand-primary uppercase">
                {product.brand}
              </span>
              <h1 className="mb-4 font-bold text-3xl text-text-dark leading-tight tracking-tight">
                {product.name}
              </h1>

              <div className="mb-6 flex items-center justify-between">
                <div className="flex items-end gap-2 text-text-dark">
                  <span className="text-2xl font-bold">
                    {formatPrice(displayPrice)}
                  </span>
                  {product.originalPrice && (
                    <span className="mb-1 text-sm text-gray-400 line-through italic">
                      {formatPrice(product.originalPrice)}
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-1.5 rounded-xl bg-brand-light border border-brand-muted px-3 py-1.5 shadow-sm">
                  <Star size={14} className="fill-brand-secondary text-brand-secondary" />
                  <span className="text-sm font-bold text-text-dark">{product.rating}</span>
                  <span className="text-xs text-gray-400">({product.reviews})</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-3 mb-8">
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    if (isOutOfStock) return;
                    onAddToCart(getProductToAdd());
                    onClose();
                  }}
                  disabled={isOutOfStock}
                  className={`flex-1 font-bold rounded-2xl py-4 shadow-sm transition-transform active:scale-95 ${isOutOfStock ? 'bg-gray-100 border-2 border-gray-200 text-gray-400 cursor-not-allowed' : 'bg-white border-2 border-brand-primary text-brand-primary hover:bg-brand-soft'}`}
                >
                  {isOutOfStock ? 'Out of Stock' : 'Add to Bag'}
                </button>
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    if (isOutOfStock) return;
                    if (onBuyNow) {
                      onBuyNow(getProductToAdd());
                    } else {
                      alert(`Proceeding to buy ${product.name}...`);
                    }
                    onClose();
                  }}
                  disabled={isOutOfStock}
                  className={`flex-[1.5] text-white font-bold rounded-2xl py-4 shadow-lg transition-transform active:scale-95 ${isOutOfStock ? 'bg-gray-300 cursor-not-allowed text-gray-500 shadow-none' : 'bg-gradient-to-r from-brand-primary to-brand-secondary shadow-brand-primary/20 hover:opacity-90'}`}
                >
                  {isOutOfStock ? 'Unavailable' : 'Buy Now'}
                </button>
              </div>

              {/* Variant Selection */}
              {product.variants && product.variants.length > 0 && (
                <div className="mb-6 border-t border-brand-muted pt-6">
                  <h3 className="text-sm font-bold text-text-dark mb-3">Select Variant</h3>
                  <div className="flex flex-wrap gap-2">
                    {product.variants.map((v) => (
                      <button
                        key={v.id}
                        onClick={() => setSelectedVariantId(v.id)}
                        className={`px-4 py-2 rounded-xl border text-sm font-bold transition-colors ${
                          selectedVariantId === v.id
                            ? 'border-brand-primary bg-brand-soft text-brand-primary'
                            : 'border-brand-muted bg-white text-gray-600 hover:border-gray-300'
                        } ${v.stockQuantity === 0 ? 'opacity-50 cursor-not-allowed' : ''}`}
                      >
                        {v.weight}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <div className="space-y-4 text-sm text-gray-500 mb-8 border-y border-brand-muted py-6">
                <p className="leading-relaxed">{product.description}</p>
                <div className="flex flex-wrap gap-2 pt-2">
                  {product.tags?.map((tag) => (
                    <span key={tag} className="bg-brand-soft border border-brand-muted text-brand-primary px-3 py-1 rounded-md text-xs font-bold">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>

              {/* Trust Badges */}
              <div className="grid grid-cols-2 gap-4 mb-24">
                <div className="flex items-center gap-3 bg-brand-light border border-brand-muted p-3 rounded-2xl shadow-sm">
                  <div className="text-brand-primary bg-white border border-brand-muted p-2 rounded-xl shadow-sm">
                    <ShieldCheck size={18} />
                  </div>
                  <div className="text-xs">
                    <p className="font-bold text-text-dark">Authentic</p>
                    <p className="text-gray-400 italic">Brand source</p>
                  </div>
                </div>
                <div className="flex items-center gap-3 bg-brand-light border border-brand-muted p-3 rounded-2xl shadow-sm">
                  <div className="text-[#E5B6A0] bg-white border border-brand-muted p-2 rounded-xl shadow-sm">
                    <Truck size={18} />
                  </div>
                  <div className="text-xs">
                    <p className="font-bold text-text-dark">Free Ship</p>
                    <p className="text-gray-400 italic">Orders ₹999+</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
