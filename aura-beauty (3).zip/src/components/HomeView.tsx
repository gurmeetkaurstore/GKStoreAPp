import React, { useState, useEffect } from "react";
import { ProductCard } from "./ProductCard";
import { Product, Category, BannerSetting } from "../types";
import { motion, AnimatePresence } from "motion/react";
import { Sparkles, ScanFace, ChevronRight, TrendingUp, Menu, Truck, X } from "lucide-react";

interface HomeViewProps {
  onProductClick: (product: Product) => void;
  onNavigate?: (tab: string) => void;
  onCategoryClick?: (categoryName: string) => void;
  categories: Category[];
  products: Product[];
  banners?: BannerSetting[];
  onAddToCart?: (product: Product) => void;
  onTrackOrder?: () => void;
}

export function HomeView({ onProductClick, onNavigate, onCategoryClick, categories, products, banners, onAddToCart, onTrackOrder }: HomeViewProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [currentBannerIndex, setCurrentBannerIndex] = useState(0);
  const viralProducts = products.filter((p) => p.isViral);
  const bestsellers = products.filter((p) => p.isBestseller);

  const defaultBanner = {
    id: 'default',
    imageUrl: 'https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&q=80&w=1200',
    mobileImageUrl: 'https://images.unsplash.com/photo-1616683693504-3ea7e9ad6fec?auto=format&fit=crop&q=80&w=800',
    heading: 'Radiant You.',
    subheading: 'Discover the new viral K-beauty routine for glass skin.',
    saleText: 'Sale is live! Flat 50% Off on Bestsellers ✨'
  };

  const activeBanners = banners && banners.length > 0 ? banners : [defaultBanner];
  
  useEffect(() => {
    if (activeBanners.length <= 1) return;
    const timer = setInterval(() => {
      setCurrentBannerIndex(prev => (prev + 1) % activeBanners.length);
    }, 2000);
    return () => clearInterval(timer);
  }, [activeBanners.length]);

  const currentBanner = activeBanners[currentBannerIndex];

  return (
    <div className="flex flex-col pb-24 relative">
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div 
            initial={{ opacity: 0 }} 
            animate={{ opacity: 1 }} 
            exit={{ opacity: 0 }} 
            className="fixed inset-0 z-[100] bg-black/50"
            onClick={() => setIsMenuOpen(false)}
          >
            <motion.div 
              initial={{ x: '-100%' }} 
              animate={{ x: 0 }} 
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 300 }}
              className="absolute top-0 left-0 bottom-0 w-[80%] max-w-sm bg-brand-light shadow-xl flex flex-col pt-8 pb-4"
              onClick={e => e.stopPropagation()}
            >
              <div className="flex justify-between items-center px-6 mb-8 mt-4">
                <h2 className="text-xl font-bold text-text-dark tracking-tight">Shop by Category</h2>
                <button onClick={() => setIsMenuOpen(false)} className="p-2 -mr-2 bg-brand-soft rounded-full text-brand-primary">
                  <X size={20} />
                </button>
              </div>
              <div className="flex-1 overflow-y-auto px-4 flex flex-col gap-3">
                {categories.map(cat => (
                  <button 
                    key={cat.id} 
                    onClick={() => {
                        setIsMenuOpen(false);
                        if (onCategoryClick) onCategoryClick(cat.name);
                        else onNavigate?.('search');
                    }}
                    className="flex justify-between items-center p-3 bg-white border border-brand-muted rounded-xl text-left font-bold text-text-dark shadow-sm hover:border-brand-primary/50 transition-colors"
                  >
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-[14px] bg-brand-soft flex justify-center items-center overflow-hidden shrink-0 text-2xl">
                         {cat.image ? <img src={cat.image} className="w-full h-full object-cover" /> : cat.icon}
                      </div>
                      <span className="text-[15px]">{cat.name}</span>
                    </div>
                    <ChevronRight size={18} className="text-gray-400" />
                  </button>
                ))}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Top Left Categories Button */}
      <button 
        onClick={() => setIsMenuOpen(true)} 
        className="absolute top-4 left-4 z-50 w-10 h-10 bg-white rounded-full flex items-center justify-center text-brand-primary border border-brand-muted shadow-sm"
      >
        <Menu size={20} />
      </button>

      {/* Top Right Track Order Button */}
      <button 
        onClick={onTrackOrder} 
        className="absolute top-4 right-4 z-50 px-3 h-10 bg-white rounded-full flex items-center justify-center text-brand-primary border border-brand-muted shadow-sm gap-2"
      >
        <Truck size={16} />
        <span className="text-xs font-bold">Track</span>
      </button>

      {/* Header Logo */}
      <div className="pt-6 pb-2 w-full flex justify-center bg-white relative z-10">
        <div className="flex justify-center">
          <img src="/logo.jpg" alt="Gurmeet Kaur Store Logo" className="w-[35px] h-[35px] object-contain" />
        </div>
      </div>

      {/* Categories */}
      <section className="pt-4 pb-4 bg-white relative z-10 w-full mb-2">
        <div className="flex gap-4 overflow-x-auto snap-x snap-mandatory no-scrollbar pb-4 px-4 w-full">
          {categories.map((cat) => (
            <button onClick={() => onCategoryClick ? onCategoryClick(cat.name) : onNavigate?.('search')} key={cat.id} className="flex flex-col items-center gap-2 min-w-[72px] shrink-0 snap-start">
              <div className="w-14 h-14 rounded-[16px] bg-brand-soft border border-brand-muted flex items-center justify-center text-2xl shadow-sm overflow-hidden shrink-0">
                {cat.image ? (
                  <img src={cat.image} alt={cat.name} className="w-full h-full object-cover" />
                ) : (
                  cat.icon
                )}
              </div>
              <span className="text-xs font-bold text-text-main opacity-80 whitespace-nowrap">{cat.name}</span>
            </button>
          ))}
        </div>
      </section>

      {/* Hero Banner Space */}
      <section className="relative w-full h-[180px] bg-brand-soft overflow-hidden border-y border-brand-muted bg-gray-900">
        <AnimatePresence initial={false}>
          <motion.div
            key={currentBannerIndex}
            initial={{ opacity: 0, x: "100%" }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: "-100%" }}
            transition={{ type: "spring", damping: 25, stiffness: 200 }}
            className="absolute inset-0 w-full h-full"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-brand-primary/20 via-transparent to-brand-secondary/20 z-0 bg-brand-soft" />
            {currentBanner.mobileImageUrl && (
              <img
                src={currentBanner.mobileImageUrl}
                className="absolute inset-0 w-full h-full object-cover block md:hidden"
                alt="Home Banner Mobile"
              />
            )}
            {currentBanner.imageUrl && (
              <img
                src={currentBanner.imageUrl}
                className="absolute inset-0 w-full h-full object-cover hidden md:block"
                alt="Home Banner Desktop"
              />
            )}
            
            <div className="absolute inset-0 bg-gradient-to-t from-gray-900/80 via-gray-900/40 to-transparent z-10" />

            <div className="absolute inset-0 z-20 flex flex-col justify-end p-6 md:p-10 text-white" style={{ paddingTop: "21px", paddingBottom: "24px", paddingRight: "24px", paddingLeft: "24px" }}>
              <div className="w-full">
                <h1 className="font-bold text-4xl md:text-5xl tracking-tight mb-2">
                  {currentBanner.heading}
                </h1>
                <p className="text-white/90 text-sm md:text-base max-w-sm mb-4 italic">
                  {currentBanner.subheading}
                </p>
                <button onClick={() => onCategoryClick ? onCategoryClick('All Products') : onNavigate?.('search')} className="bg-white text-brand-primary px-6 py-2.5 rounded-xl text-sm font-bold shadow-sm flex items-center gap-2">
                  Shop Now <ChevronRight size={16} />
                </button>
              </div>
            </div>
          </motion.div>
        </AnimatePresence>
      </section>

      {/* Sale Marquee line */}
      {currentBanner.saleText && (
        <div className="bg-gradient-to-r from-brand-primary/10 via-brand-secondary/10 to-brand-primary/10 py-3 overflow-hidden border-b border-brand-muted flex items-center">
          <div className="animate-marquee whitespace-nowrap text-brand-primary font-bold text-sm tracking-wider uppercase inline-block">
            {currentBanner.saleText} &nbsp;&nbsp; • &nbsp;&nbsp; {currentBanner.saleText} &nbsp;&nbsp; • &nbsp;&nbsp; {currentBanner.saleText} &nbsp;&nbsp; • &nbsp;&nbsp; {currentBanner.saleText} &nbsp;&nbsp; • &nbsp;&nbsp; {currentBanner.saleText}
          </div>
        </div>
      )}

      {/* New Arrivals */}
      <section className="mt-6 px-4">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-bold text-text-dark flex items-center gap-2 tracking-tight">
            New Arrivals <Sparkles size={18} className="text-brand-primary" />
          </h2>
          <button onClick={() => onCategoryClick ? onCategoryClick('New Arrivals') : onNavigate?.('search')} className="text-xs font-bold text-brand-primary px-3 py-1 bg-brand-soft rounded-full">View All</button>
        </div>
        <div className="flex gap-4 overflow-x-auto no-scrollbar pb-4 snap-x snap-mandatory -mx-4 px-4 w-[calc(100%+2rem)]">
          {products.filter(p => p.isNew).map((p, index) => (
            <motion.div 
              key={p.id}
              className="min-w-[160px] max-w-[160px] shrink-0 snap-center"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <ProductCard product={p} onClick={onProductClick} onAddToCart={onAddToCart} />
            </motion.div>
          ))}
        </div>
      </section>

      {/* Viral Products */}
      <section className="mt-10 px-4">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-bold text-text-dark flex items-center gap-2 tracking-tight">
            Trending Now <TrendingUp size={18} className="text-brand-primary" />
          </h2>
          <button onClick={() => onCategoryClick ? onCategoryClick('Trending Now') : onNavigate?.('search')} className="text-xs font-bold text-brand-primary px-3 py-1 bg-brand-soft rounded-full">View All</button>
        </div>
        <div className="flex gap-4 overflow-x-auto no-scrollbar pb-4 snap-x snap-mandatory -mx-4 px-4 w-[calc(100%+2rem)]">
          {viralProducts.map((p, index) => (
            <motion.div 
              key={p.id}
              className="min-w-[160px] max-w-[160px] shrink-0 snap-center"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <ProductCard product={p} onClick={onProductClick} onAddToCart={onAddToCart} />
            </motion.div>
          ))}
        </div>
      </section>

      {/* Bestsellers */}
      <section className="mt-10 px-4 mb-8">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-bold text-text-dark tracking-tight">Bestsellers</h2>
          <button onClick={() => onCategoryClick ? onCategoryClick('Bestsellers') : onNavigate?.('search')} className="text-xs font-bold text-brand-primary px-3 py-1 bg-brand-soft rounded-full">View All</button>
        </div>
        <div className="flex gap-4 overflow-x-auto no-scrollbar pb-4 snap-x snap-mandatory -mx-4 px-4 w-[calc(100%+2rem)]">
          {bestsellers.map((p, index) => (
            <motion.div 
              key={p.id}
              className="min-w-[160px] max-w-[160px] shrink-0 snap-center"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <ProductCard product={p} onClick={onProductClick} onAddToCart={onAddToCart} />
            </motion.div>
          ))}
        </div>
      </section>
    </div>
  );
}
