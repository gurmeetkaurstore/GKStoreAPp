import React, { useState, useEffect } from 'react';
import { ChevronLeft, User } from 'lucide-react';
import { db, auth, handleFirestoreError, OperationType } from '../firebase';
import { doc, getDoc, setDoc } from 'firebase/firestore';

export function PersonalInfoView({ userId, onBack }: { userId: string, onBack: () => void }) {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    phone: '',
    dob: '',
    gender: 'prefer-not'
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const fetchInfo = async () => {
      try {
        const docRef = doc(db, 'userProfiles', userId);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          const data = docSnap.data();
          setFormData({
            firstName: data.firstName || '',
            lastName: data.lastName || '',
            phone: data.phone || '',
            dob: data.dob || '',
            gender: data.gender || 'prefer-not'
          });
        }
      } catch (error) {
        handleFirestoreError(error, OperationType.GET, `userProfiles/${userId}`);
      } finally {
        setLoading(false);
      }
    };
    fetchInfo();
  }, [userId]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await setDoc(doc(db, 'userProfiles', userId), formData, { merge: true });
      alert('Personal information updated successfully!');
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `userProfiles/${userId}`);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-brand-light pb-24">
      <div className="bg-white p-4 flex items-center border-b border-brand-muted sticky top-0 z-20 shadow-sm">
        <button onClick={onBack} className="p-2 hover:bg-brand-soft rounded-full transition-colors mr-2">
          <ChevronLeft size={24} className="text-brand-primary" />
        </button>
        <h1 className="text-xl font-bold text-text-dark tracking-tight">Personal Information</h1>
      </div>

      <div className="p-4 flex flex-col gap-4 max-w-2xl mx-auto w-full mt-4">
        <div className="bg-white rounded-[32px] p-6 shadow-sm border border-brand-muted">
          <div className="flex items-center gap-3 mb-6 border-b border-brand-muted pb-4">
             <div className="w-12 h-12 bg-brand-soft rounded-full flex items-center justify-center text-brand-primary">
                 <User size={24} />
             </div>
             <div>
                 <h2 className="text-lg font-bold text-text-dark">Your Details</h2>
                 <p className="text-sm text-gray-500">Update your personal information below.</p>
             </div>
          </div>
          
          {loading ? (
            <div className="animate-pulse space-y-4">
              <div className="h-10 bg-brand-soft rounded-xl"></div>
              <div className="h-10 bg-brand-soft rounded-xl"></div>
              <div className="h-10 bg-brand-soft rounded-xl"></div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-gray-500 mb-1 uppercase tracking-wider">First Name</label>
                  <input type="text" value={formData.firstName} onChange={e => setFormData({...formData, firstName: e.target.value})} className="w-full px-4 py-3 rounded-xl border border-brand-muted bg-brand-light focus:outline-none focus:ring-2 focus:ring-brand-primary/50 text-sm font-medium" placeholder="Jane" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-500 mb-1 uppercase tracking-wider">Last Name</label>
                  <input type="text" value={formData.lastName} onChange={e => setFormData({...formData, lastName: e.target.value})} className="w-full px-4 py-3 rounded-xl border border-brand-muted bg-brand-light focus:outline-none focus:ring-2 focus:ring-brand-primary/50 text-sm font-medium" placeholder="Doe" />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-500 mb-1 uppercase tracking-wider">Email Address</label>
                <input type="email" value={auth.currentUser?.email || ''} readOnly className="w-full px-4 py-3 rounded-xl border border-brand-muted bg-brand-soft text-gray-500 text-sm font-medium cursor-not-allowed" />
                <p className="text-xs text-gray-400 mt-1">Email cannot be changed.</p>
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-500 mb-1 uppercase tracking-wider">Phone</label>
                <input type="tel" value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} className="w-full px-4 py-3 rounded-xl border border-brand-muted bg-brand-light focus:outline-none focus:ring-2 focus:ring-brand-primary/50 text-sm font-medium" placeholder="+91 98765 43210" />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-gray-500 mb-1 uppercase tracking-wider">Date of Birth</label>
                  <input type="date" value={formData.dob} onChange={e => setFormData({...formData, dob: e.target.value})} className="w-full px-4 py-3 rounded-xl border border-brand-muted bg-brand-light focus:outline-none focus:ring-2 focus:ring-brand-primary/50 text-sm font-medium" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-500 mb-1 uppercase tracking-wider">Gender</label>
                  <select value={formData.gender} onChange={e => setFormData({...formData, gender: e.target.value})} className="w-full px-4 py-3 rounded-xl border border-brand-muted bg-brand-light focus:outline-none focus:ring-2 focus:ring-brand-primary/50 text-sm font-medium appearance-none">
                    <option value="prefer-not">Prefer not to say</option>
                    <option value="female">Female</option>
                    <option value="male">Male</option>
                    <option value="other">Other</option>
                  </select>
                </div>
              </div>

              <button disabled={saving} type="submit" className="w-full py-3.5 mt-6 bg-brand-primary text-white rounded-xl font-bold shadow-sm hover:bg-brand-secondary transition-colors text-sm disabled:opacity-70 disabled:cursor-not-allowed">
                {saving ? 'Saving...' : 'Save Changes'}
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
