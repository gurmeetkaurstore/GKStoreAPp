import React, { useState } from 'react';
import { Search } from 'lucide-react';
import { Product } from '../types';
import { ProductCard } from './ProductCard';

interface SearchViewProps {
  products: Product[];
  onProductClick: (product: Product) => void;
  onAddToCart: (product: Product) => void;
  initialQuery?: string;
}

export function SearchView({ products, onProductClick, onAddToCart, initialQuery = '' }: SearchViewProps) {
  const [query, setQuery] = useState(initialQuery);

  const filteredProducts = products.filter(product => {
    if (query.toLowerCase() === 'new arrivals') return product.isNew;
    if (query.toLowerCase() === 'trending now') return product.isViral;
    if (query.toLowerCase() === 'bestsellers') return product.isBestseller;
    if (query.toLowerCase() === 'all products') return true;
    
    return product.name.toLowerCase().includes(query.toLowerCase()) || 
           product.description.toLowerCase().includes(query.toLowerCase()) ||
           product.category.toLowerCase().includes(query.toLowerCase());
  });

  return (
    <div className="pb-24 pt-6 px-4">
      {/* Search Input */}
      <div className="relative mb-6">
        <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-gray-400">
          <Search size={20} />
        </div>
        <input
          type="text"
          className="w-full pl-12 pr-4 py-3 bg-brand-soft border border-brand-muted text-text-dark rounded-2xl focus:outline-none focus:ring-2 focus:ring-brand-primary/50 text-sm font-medium transition-all"
          placeholder="Search for products, categories..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          autoFocus
        />
      </div>

      {/* Results */}
      {query.trim() === '' ? (
        <div className="flex flex-col items-center justify-center h-[50vh] text-center opacity-70">
          <div className="w-16 h-16 bg-brand-soft border border-brand-muted rounded-2xl flex items-center justify-center mb-4 text-brand-primary">
            <Search size={28} />
          </div>
          <h2 className="text-lg font-bold text-text-dark mb-2">Type to search...</h2>
          <p className="text-gray-400 text-sm italic">Find your perfect match</p>
        </div>
      ) : filteredProducts.length > 0 ? (
        <div className="grid grid-cols-2 gap-4">
          {filteredProducts.map((p) => (
            <ProductCard
              key={p.id}
              product={p}
              onClick={() => onProductClick(p)}
              onAddToCart={() => onAddToCart(p)}
            />
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center h-[50vh] text-center opacity-70">
          <h2 className="text-lg font-bold text-text-dark mb-2">No results found</h2>
          <p className="text-gray-400 text-sm italic">Try another search term</p>
        </div>
      )}
    </div>
  );
}
