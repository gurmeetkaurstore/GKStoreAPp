import React from "react";
import { Order } from "../types";
import { ChevronLeft, Package, Clock, Truck, CheckCircle, XCircle } from "lucide-react";

interface MyOrdersViewProps {
  orders: Order[];
  onBack: () => void;
  onTrackOrder: (order: Order) => void;
}

export function MyOrdersView({ orders, onBack, onTrackOrder }: MyOrdersViewProps) {
  const getStatusIcon = (status: string) => {
    switch(status) {
      case 'processing': return <Clock size={16} className="text-yellow-500" />;
      case 'shipped': return <Truck size={16} className="text-blue-500" />;
      case 'delivered': return <CheckCircle size={16} className="text-green-500" />;
      case 'cancelled': return <XCircle size={16} className="text-red-500" />;
      default: return <Package size={16} className="text-gray-500" />;
    }
  };

  const getStatusText = (status: string) => {
    return status.charAt(0).toUpperCase() + status.slice(1);
  };

  return (
    <div className="flex flex-col h-full bg-brand-light pb-24">
      <div className="bg-white p-4 flex items-center border-b border-brand-muted sticky top-0 z-20">
        <button onClick={onBack} className="p-2 hover:bg-brand-soft rounded-full transition-colors mr-2">
          <ChevronLeft size={24} className="text-brand-primary" />
        </button>
        <h1 className="text-xl font-bold text-text-dark">My Orders</h1>
      </div>

      <div className="p-4 flex flex-col gap-4">
        {orders.length === 0 ? (
          <div className="text-center py-12 text-gray-400 font-medium">
            <Package size={48} className="mx-auto mb-4 opacity-50" />
            <p>You haven't placed any orders yet.</p>
          </div>
        ) : (
          [...orders].sort((a,b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()).map(order => (
            <div key={order.id} className="bg-white p-4 rounded-3xl border border-brand-muted shadow-sm flex flex-col gap-3">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-xs font-bold text-gray-500 font-mono">#{order.id.slice(0, 8)}</p>
                  <p className="text-xs text-gray-400">{new Date(order.createdAt).toLocaleDateString()}</p>
                  {order.customerName && (
                    <p className="text-xs font-bold text-text-dark mt-1">Name: {order.customerName}</p>
                  )}
                  {order.paymentMethod && (
                    <p className="text-[10px] font-bold text-brand-primary mt-1">Payment: {order.paymentMethod}</p>
                  )}
                  {order.courierPartner && (
                    <p className="text-xs font-bold text-brand-primary mt-1">Via: {order.courierPartner}</p>
                  )}
                  {order.trackingNumber && (
                    <p className="text-xs font-bold text-gray-500 mt-1">Tracking NO: <span className="text-text-dark">{order.trackingNumber}</span></p>
                  )}
                </div>
                <div className="flex items-center gap-1 text-xs font-bold px-2 py-1 bg-brand-soft rounded-full">
                  {getStatusIcon(order.status)}
                  <span className="text-text-dark">{getStatusText(order.status)}</span>
                </div>
              </div>

              <div className="border-t border-b border-brand-muted py-3 my-1">
                {order.items.map((item, idx) => (
                  <div key={idx} className="flex justify-between items-center text-sm py-1">
                    <span className="text-text-dark font-medium line-clamp-1">{item.quantity}x {item.name}</span>
                    <span className="text-text-dark font-bold whitespace-nowrap ml-2">₹{(item.price * item.quantity).toFixed(2)}</span>
                  </div>
                ))}
              </div>

              <div className="flex justify-between items-center">
                <span className="text-sm font-bold text-text-dark">Total: ₹{order.total.toFixed(2)}</span>
                <button 
                  onClick={() => onTrackOrder(order)}
                  className="text-xs font-bold bg-brand-primary text-white px-4 py-2 rounded-xl shadow-sm hover:bg-brand-secondary transition-colors"
                >
                  Track Order
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
