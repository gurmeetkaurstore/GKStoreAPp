import React, { useState } from "react";
import { formatPrice } from "../utils";
import { Product } from "../types";
import { Star, Sparkles, TrendingUp, Check } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface ProductCardProps {
  key?: React.Key;
  product: Product;
  onClick: (product: Product) => void;
  onAddToCart?: (product: Product) => void;
}

export function ProductCard({ product, onClick, onAddToCart }: ProductCardProps) {
  const [isAdded, setIsAdded] = useState(false);

  const isOutOfStock = product.variants?.length 
    ? product.variants.every(v => v.stockQuantity === 0)
    : (product.stockQuantity === 0);

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isOutOfStock) return;
    if (onAddToCart) {
      onAddToCart(product);
      setIsAdded(true);
      setTimeout(() => setIsAdded(false), 2000);
    }
  };

  return (
    <motion.div
      whileHover={{ y: -4 }}
      className="group relative flex flex-col overflow-hidden rounded-3xl bg-white shadow-sm transition-all hover:shadow-md cursor-pointer border border-brand-muted"
      onClick={() => onClick(product)}
    >
      <div className="relative aspect-square overflow-hidden bg-brand-light">
        <img
          src={product.image}
          alt={product.name}
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <div className="absolute top-2 left-2 flex flex-col gap-1">
          {product.isViral && (
            <span className="flex items-center gap-1 rounded-full bg-brand-primary px-2 py-1 text-[10px] font-bold text-white shadow-sm">
              <TrendingUp size={10} /> VIRAL
            </span>
          )}
          {product.isNew && (
            <span className="flex items-center gap-1 rounded-full bg-text-dark px-2 py-1 text-[10px] font-bold text-white shadow-sm">
              <Sparkles size={10} /> NEW
            </span>
          )}
        </div>
        <div className="absolute top-2 right-2 flex items-center gap-1 rounded-xl bg-white border border-brand-muted px-2 py-1 text-[10px] font-bold text-text-dark shadow-sm">
          <Star size={10} className="fill-brand-secondary text-brand-secondary" />
          <span>{product.rating}</span>
        </div>
      </div>

      <div className="flex flex-1 flex-col p-4">
        <span className="mb-1 text-[10px] font-bold tracking-widest text-brand-primary uppercase opacity-80">
          {product.brand}
        </span>
        <h3 className="line-clamp-2 text-sm font-bold leading-tight text-text-dark">
          {product.name}
        </h3>
        
        <div className="mt-auto pt-3 flex items-end justify-between gap-2">
          <div className="flex items-end gap-2">
            <span className="text-sm font-bold text-brand-primary">
              {formatPrice(product.price)}
            </span>
            {product.originalPrice && (
              <span className="text-xs text-gray-400 line-through opacity-60">
                {formatPrice(product.originalPrice)}
              </span>
            )}
          </div>
          {onAddToCart && (
            <button 
              onClick={handleAddToCart}
              disabled={isOutOfStock}
              className={`text-[10px] font-bold px-3 py-1.5 rounded-lg shadow-sm transition-colors flex items-center gap-1 min-w-[50px] justify-center ${isOutOfStock ? 'bg-gray-200 text-gray-500 cursor-not-allowed' : isAdded ? 'bg-text-dark text-white' : 'bg-brand-primary text-white hover:bg-brand-secondary'}`}
            >
              <AnimatePresence mode="wait">
                {isOutOfStock ? (
                  <motion.span 
                    key="out" 
                    initial={{ scale: 0.5, opacity: 0 }} 
                    animate={{ scale: 1, opacity: 1 }} 
                    exit={{ scale: 0.5, opacity: 0 }}
                  >
                    Out of Stock
                  </motion.span>
                ) : isAdded ? (
                  <motion.span 
                    key="added" 
                    initial={{ scale: 0.5, opacity: 0 }} 
                    animate={{ scale: 1, opacity: 1 }} 
                    exit={{ scale: 0.5, opacity: 0 }}
                    className="flex items-center gap-1"
                  >
                    <Check size={12} />
                  </motion.span>
                ) : (
                  <motion.span 
                    key="add" 
                    initial={{ scale: 0.5, opacity: 0 }} 
                    animate={{ scale: 1, opacity: 1 }} 
                    exit={{ scale: 0.5, opacity: 0 }}
                  >
                    Add
                  </motion.span>
                )}
              </AnimatePresence>
            </button>
          )}
        </div>
      </div>
    </motion.div>
  );
}
