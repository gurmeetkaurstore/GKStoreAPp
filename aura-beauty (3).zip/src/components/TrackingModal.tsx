import React, { useState, useEffect } from "react";
import { Order } from "../types";
import { Truck, X, Search, Package, CheckCircle, Clock } from "lucide-react";

interface TrackingModalProps {
  isOpen: boolean;
  onClose: () => void;
  orders: Order[];
  initialOrderId?: string;
}

export function TrackingModal({ isOpen, onClose, orders, initialOrderId = "" }: TrackingModalProps) {
  const [orderId, setOrderId] = useState(initialOrderId);
  const [result, setResult] = useState<Order | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    if (isOpen) {
      if (initialOrderId) {
        setOrderId(initialOrderId);
        const order = orders.find(o => o.id === initialOrderId);
        if (order) {
          setResult(order);
          setError("");
        }
      } else {
        setOrderId("");
        setResult(null);
        setError("");
      }
    }
  }, [isOpen, initialOrderId, orders]);

  if (!isOpen) return null;

  const handleTrack = () => {
    setError("");
    setResult(null);
    if (!orderId.trim()) {
      setError("Please enter your Order ID");
      return;
    }

    const order = orders.find(o => o.id === orderId.trim() || o.id.startsWith(orderId.trim()));
    if (!order) {
      setError("Order not found. Please check your Order ID.");
      return;
    }

    setResult(order);
  };

  const getStatusColor = (status: string) => {
    switch(status) {
      case 'processing': return "text-yellow-500 bg-yellow-50";
      case 'shipped': return "text-blue-500 bg-blue-50";
      case 'delivered': return "text-green-500 bg-green-50";
      case 'cancelled': return "text-red-500 bg-red-50";
      default: return "text-gray-500 bg-gray-50";
    }
  };

  const getStatusIcon = (status: string) => {
    switch(status) {
      case 'processing': return <Clock size={20} className="text-yellow-500" />;
      case 'shipped': return <Truck size={20} className="text-blue-500" />;
      case 'delivered': return <CheckCircle size={20} className="text-green-500" />;
      default: return <Package size={20} className="text-gray-500" />;
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <div className="bg-white w-full max-w-sm rounded-[32px] p-6 shadow-xl relative animate-in fade-in zoom-in-95 duration-200">
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 w-8 h-8 flex items-center justify-center rounded-full bg-brand-soft text-text-main border border-brand-muted hover:bg-brand-muted transition-colors"
        >
          <X size={16} />
        </button>

        <div className="text-center mb-6">
          <div className="w-12 h-12 bg-brand-soft border border-brand-muted rounded-2xl flex items-center justify-center text-brand-primary mx-auto mb-3 shadow-sm">
            <Truck size={24} />
          </div>
          <h2 className="text-xl font-bold text-text-dark tracking-tight">Track Your Order</h2>
          <p className="text-sm text-gray-500 mt-1">Enter your order ID below</p>
        </div>

        <div className="flex gap-2 mb-4">
          <div className="relative flex-1">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input 
              type="text" 
              value={orderId}
              onChange={(e) => setOrderId(e.target.value)}
              placeholder="e.g. ord_123456"
              className="w-full pl-9 pr-4 py-3 bg-brand-light border border-brand-muted rounded-2xl text-sm font-medium text-text-main placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-brand-primary/20"
              onKeyDown={(e) => e.key === 'Enter' && handleTrack()}
            />
          </div>
          <button 
            onClick={handleTrack}
            className="px-4 py-3 bg-brand-primary text-white rounded-2xl font-bold hover:bg-brand-secondary transition-colors"
          >
            Track
          </button>
        </div>

        {error && (
          <div className="p-3 bg-red-50 text-red-600 rounded-xl text-sm font-medium border border-red-100 text-center">
            {error}
          </div>
        )}

        {result && (
          <div className="mt-6 border-t border-brand-muted pt-6">
            <div className="flex items-center justify-between mb-4">
              <span className="text-sm font-bold text-gray-500 uppercase tracking-wider">Status Overview</span>
              <div className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold ${getStatusColor(result.status)}`}>
                {result.status.toUpperCase()}
              </div>
            </div>

            <div className="p-4 bg-brand-soft border border-brand-muted rounded-2xl shadow-sm mb-4">
              <div className="flex items-center gap-3 mb-2">
                {getStatusIcon(result.status)}
                <div>
                  <p className="text-sm font-bold text-text-dark">Current Stage</p>
                  <p className="text-xs text-gray-500">Order is {result.status}</p>
                </div>
              </div>
              {result.courierPartner && (
                <div className="mt-3 pt-3 border-t border-brand-muted/50">
                  <p className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">Courier Partner</p>
                  <p className="text-sm font-bold text-text-dark">{result.courierPartner}</p>
                </div>
              )}
              {result.trackingNumber && (
                <div className="mt-3 pt-3 border-t border-brand-muted/50">
                  <p className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">Tracking Number</p>
                  <p className="text-sm font-bold text-text-dark">{result.trackingNumber}</p>
                </div>
              )}
            </div>

            {result.trackingLink ? (
              <a 
                href={result.trackingLink} 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-full flex items-center justify-center gap-2 bg-text-dark text-white font-bold py-3 px-4 rounded-xl shadow-sm hover:opacity-90 transition-opacity"
              >
                View Live Tracking <Truck size={16} />
              </a>
            ) : (
              <p className="text-xs text-center text-gray-400 font-medium">Tracking link not available yet</p>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
