import React from "react";
import { ChevronLeft, Sparkles, Heart, User, Settings, Shield, FileText } from "lucide-react";

interface ProfileSubViewPlaceholderProps {
  title: string;
  onBack: () => void;
}

export function ProfileSubViewPlaceholder({ title, onBack }: ProfileSubViewPlaceholderProps) {
  const getIcon = () => {
    switch (title) {
      case 'Wishlist': return <Heart size={48} className="mx-auto mb-4 opacity-50" />;
      case 'Beauty Profile': return <User size={48} className="mx-auto mb-4 opacity-50" />;
      case 'Settings': return <Settings size={48} className="mx-auto mb-4 opacity-50" />;
      case 'Privacy Policy': return <Shield size={48} className="mx-auto mb-4 opacity-50" />;
      case 'Terms of Service': return <FileText size={48} className="mx-auto mb-4 opacity-50" />;
      default: return <Sparkles size={48} className="mx-auto mb-4 opacity-50" />;
    }
  };

  return (
    <div className="flex flex-col h-full bg-brand-light pb-24">
      <div className="bg-white p-4 flex items-center border-b border-brand-muted sticky top-0 z-20">
        <button onClick={onBack} className="p-2 hover:bg-brand-soft rounded-full transition-colors mr-2">
          <ChevronLeft size={24} className="text-brand-primary" />
        </button>
        <h1 className="text-xl font-bold text-text-dark">{title}</h1>
      </div>

      <div className="p-4 flex flex-col gap-4">
        <div className="text-center py-12 text-gray-400 font-medium bg-white rounded-3xl border border-brand-muted shadow-sm">
          {getIcon()}
          <p>This feature is coming soon.</p>
        </div>
      </div>
    </div>
  );
}
