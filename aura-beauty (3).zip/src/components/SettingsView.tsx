import React from "react";
import { ChevronLeft, MapPin, User, ChevronRight, Shield, FileText, Sparkles } from "lucide-react";

interface SettingsViewProps {
  onBack: () => void;
  onNavigateSubView: (view: string) => void;
}

export function SettingsView({ onBack, onNavigateSubView }: SettingsViewProps) {
  return (
    <div className="flex flex-col h-full bg-brand-light pb-24">
      <div className="bg-white p-4 flex items-center border-b border-brand-muted sticky top-0 z-20 shadow-sm">
        <button onClick={onBack} className="p-2 hover:bg-brand-soft rounded-full transition-colors mr-2">
          <ChevronLeft size={24} className="text-brand-primary" />
        </button>
        <h1 className="text-xl font-bold text-text-dark tracking-tight">Settings</h1>
      </div>

      <div className="p-4 flex flex-col gap-4 max-w-sm mx-auto w-full mt-4">
        <div 
          onClick={() => onNavigateSubView('Privacy Policy')}
          className="bg-white p-4 rounded-2xl border border-brand-muted shadow-sm flex items-center justify-between cursor-pointer hover:border-brand-primary transition-colors group"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-brand-soft rounded-xl flex items-center justify-center text-brand-primary group-hover:bg-brand-primary group-hover:text-white transition-colors">
               <Shield size={20} />
            </div>
            <div>
               <p className="text-sm font-bold text-text-dark">Privacy Policy</p>
               <p className="text-xs text-gray-500">How we protect your data</p>
            </div>
          </div>
          <ChevronRight size={20} className="text-gray-400 group-hover:text-brand-primary transition-colors" />
        </div>

        <div 
          onClick={() => onNavigateSubView('Terms of Service')}
          className="bg-white p-4 rounded-2xl border border-brand-muted shadow-sm flex items-center justify-between cursor-pointer hover:border-brand-primary transition-colors group"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-brand-soft rounded-xl flex items-center justify-center text-brand-primary group-hover:bg-brand-primary group-hover:text-white transition-colors">
               <FileText size={20} />
            </div>
            <div>
               <p className="text-sm font-bold text-text-dark">Terms of Service</p>
               <p className="text-xs text-gray-500">Rules and guidelines</p>
            </div>
          </div>
          <ChevronRight size={20} className="text-gray-400 group-hover:text-brand-primary transition-colors" />
        </div>
      </div>
    </div>
  );
}
