import React, { useState, useEffect } from 'react';
import { ChevronLeft, Plus, MapPin, Trash2, Edit2, X } from 'lucide-react';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { collection, onSnapshot, doc, deleteDoc, setDoc } from 'firebase/firestore';

interface Address {
  id: string;
  name: string;
  phone: string;
  street: string;
  city: string;
  state: string;
  zipCode: string;
}

export function AddressBookView({ userId, onBack }: { userId: string, onBack: () => void }) {
  const [addresses, setAddresses] = useState<Address[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [editingAddress, setEditingAddress] = useState<Address | null>(null);
  const [formData, setFormData] = useState<Omit<Address, 'id'>>({
    name: '',
    phone: '',
    street: '',
    city: '',
    state: '',
    zipCode: ''
  });

  useEffect(() => {
    const addressesRef = collection(db, `users/${userId}/addresses`);
    const unsubscribe = onSnapshot(addressesRef, (snapshot) => {
      const addrs: Address[] = [];
      snapshot.forEach(docSnap => {
        addrs.push({ id: docSnap.id, ...docSnap.data() } as Address);
      });
      setAddresses(addrs);
    }, (error) => handleFirestoreError(error, OperationType.LIST, `users/${userId}/addresses`));
    return () => unsubscribe();
  }, [userId]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const addrId = editingAddress ? editingAddress.id : `addr-${Date.now()}`;
      await setDoc(doc(db, `users/${userId}/addresses`, addrId), formData);
      setShowModal(false);
      setEditingAddress(null);
      setFormData({ name: '', phone: '', street: '', city: '', state: '', zipCode: '' });
    } catch (error) {
      handleFirestoreError(error, editingAddress ? OperationType.UPDATE : OperationType.CREATE, `users/${userId}/addresses`);
    }
  };

  const handleDelete = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!confirm('Are you sure you want to delete this address?')) return;
    try {
      await deleteDoc(doc(db, `users/${userId}/addresses`, id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `users/${userId}/addresses`);
    }
  };

  const handleEdit = (addr: Address) => {
    setEditingAddress(addr);
    setFormData({
      name: addr.name,
      phone: addr.phone,
      street: addr.street,
      city: addr.city,
      state: addr.state,
      zipCode: addr.zipCode
    });
    setShowModal(true);
  };

  return (
    <div className="flex flex-col h-full bg-brand-light pb-24">
      <div className="bg-white p-4 flex items-center justify-between border-b border-brand-muted sticky top-0 z-20 shadow-sm">
        <div className="flex items-center gap-2">
          <button onClick={onBack} className="p-2 hover:bg-brand-soft rounded-full transition-colors">
            <ChevronLeft size={24} className="text-brand-primary" />
          </button>
          <h1 className="text-xl font-bold text-text-dark tracking-tight">Address Book</h1>
        </div>
        <button onClick={() => {
          setEditingAddress(null);
          setFormData({ name: '', phone: '', street: '', city: '', state: '', zipCode: '' });
          setShowModal(true);
        }} className="p-2 bg-brand-soft text-brand-primary rounded-full hover:bg-brand-muted transition-colors">
          <Plus size={20} />
        </button>
      </div>

      <div className="p-4 flex flex-col gap-4 max-w-2xl mx-auto w-full">
        {addresses.length === 0 ? (
          <div className="bg-white rounded-3xl p-8 text-center border border-brand-muted shadow-sm mt-8">
            <div className="w-16 h-16 bg-brand-soft rounded-full flex items-center justify-center mx-auto mb-4 text-brand-primary">
              <MapPin size={28} />
            </div>
            <h3 className="text-lg font-bold text-text-dark mb-2">No Saved Addresses</h3>
            <p className="text-sm text-gray-500 mb-6">Add an address for faster checkout.</p>
            <button onClick={() => setShowModal(true)} className="px-6 py-2.5 bg-brand-primary text-white font-bold rounded-xl shadow-sm text-sm hover:bg-brand-secondary transition-colors">
              Add New Address
            </button>
          </div>
        ) : (
          addresses.map(addr => (
            <div key={addr.id} className="bg-white rounded-[24px] p-5 shadow-sm border border-brand-muted relative group">
              <div className="pr-12">
                <p className="font-bold text-text-dark mb-1">{addr.name}</p>
                <div className="text-sm text-gray-500 space-y-0.5">
                  <p>{addr.street}</p>
                  <p>{addr.city}, {addr.state} {addr.zipCode}</p>
                  <p className="font-medium mt-2">Phone: {addr.phone}</p>
                </div>
              </div>
              <div className="absolute top-5 right-5 flex flex-col gap-2">
                <button onClick={() => handleEdit(addr)} className="p-2 bg-brand-soft text-brand-primary rounded-full hover:bg-brand-muted transition-colors">
                  <Edit2 size={16} />
                </button>
                <button onClick={(e) => handleDelete(addr.id, e)} className="p-2 bg-[#FFF0F3] text-[#F27D9A] rounded-full hover:bg-[#FDE2E7] transition-colors">
                  <Trash2 size={16} />
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-[32px] w-full max-w-md p-6 relative shadow-xl max-h-[90vh] overflow-y-auto">
            <button onClick={() => setShowModal(false)} className="absolute top-6 right-6 text-gray-400 hover:text-text-dark transition-colors">
              <X size={20} />
            </button>
            <h2 className="text-xl font-bold text-text-dark mb-6 pr-8">
              {editingAddress ? 'Edit Address' : 'Add New Address'}
            </h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-gray-500 mb-1 uppercase tracking-wider">Full Name</label>
                <input required type="text" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} className="w-full px-4 py-3 rounded-xl border border-brand-muted bg-brand-light focus:outline-none focus:ring-2 focus:ring-brand-primary/50 text-sm font-medium" />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-500 mb-1 uppercase tracking-wider">Phone</label>
                <input required type="tel" value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} className="w-full px-4 py-3 rounded-xl border border-brand-muted bg-brand-light focus:outline-none focus:ring-2 focus:ring-brand-primary/50 text-sm font-medium" />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-500 mb-1 uppercase tracking-wider">Street Address</label>
                <textarea required rows={2} value={formData.street} onChange={e => setFormData({...formData, street: e.target.value})} className="w-full px-4 py-3 rounded-xl border border-brand-muted bg-brand-light focus:outline-none focus:ring-2 focus:ring-brand-primary/50 text-sm font-medium resize-none"></textarea>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-gray-500 mb-1 uppercase tracking-wider">City</label>
                  <input required type="text" value={formData.city} onChange={e => setFormData({...formData, city: e.target.value})} className="w-full px-4 py-3 rounded-xl border border-brand-muted bg-brand-light focus:outline-none focus:ring-2 focus:ring-brand-primary/50 text-sm font-medium" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-500 mb-1 uppercase tracking-wider">State</label>
                  <input required type="text" value={formData.state} onChange={e => setFormData({...formData, state: e.target.value})} className="w-full px-4 py-3 rounded-xl border border-brand-muted bg-brand-light focus:outline-none focus:ring-2 focus:ring-brand-primary/50 text-sm font-medium" />
                </div>
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-500 mb-1 uppercase tracking-wider">ZIP Code</label>
                <input required type="text" value={formData.zipCode} onChange={e => setFormData({...formData, zipCode: e.target.value})} className="w-full px-4 py-3 rounded-xl border border-brand-muted bg-brand-light focus:outline-none focus:ring-2 focus:ring-brand-primary/50 text-sm font-medium" />
              </div>
              <button type="submit" className="w-full py-3 mt-4 bg-brand-primary text-white rounded-xl font-bold shadow-sm hover:bg-brand-secondary transition-colors text-sm">
                Save Address
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
