import React from "react";
import { ChevronLeft } from "lucide-react";

interface LegalDocumentViewProps {
  title: string;
  onBack: () => void;
}

export function LegalDocumentView({ title, onBack }: LegalDocumentViewProps) {
  const getDocumentContent = () => {
    if (title === 'Privacy Policy') {
      return (
        <div className="space-y-6 text-sm text-gray-600 leading-relaxed">
          <section>
            <h2 className="text-lg font-bold text-text-dark mb-2">1. Introduction</h2>
            <p>
              Welcome to Gurmeet Kaur Store. We respect your privacy and are committed to protecting your personal data. 
              This privacy policy will inform you as to how we look after your personal data when you visit our website 
              and tell you about your privacy rights and how the law protects you.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold text-text-dark mb-2">2. The Data We Collect</h2>
            <p>
              We may collect, use, store and transfer different kinds of personal data about you which we have grouped together follows:
            </p>
            <ul className="list-disc pl-5 mt-2 space-y-1">
              <li><strong>Identity Data:</strong> includes first name, last name, username or similar identifier.</li>
              <li><strong>Contact Data:</strong> includes billing address, delivery address, email address and telephone numbers.</li>
              <li><strong>Transaction Data:</strong> includes details about payments to and from you and other details of products you have purchased from us.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-lg font-bold text-text-dark mb-2">3. How We Use Your Data</h2>
            <p>
              We will only use your personal data when the law allows us to. Most commonly, we will use your personal data in the following circumstances:
            </p>
            <ul className="list-disc pl-5 mt-2 space-y-1">
              <li>Where we need to perform the contract we are about to enter into or have entered into with you.</li>
              <li>Where it is necessary for our legitimate interests and your interests and fundamental rights do not override those interests.</li>
              <li>Where we need to comply with a legal obligation.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-lg font-bold text-text-dark mb-2">4. Data Security</h2>
            <p>
              We have put in place appropriate security measures to prevent your personal data from being accidentally lost, used or accessed in an unauthorised way, altered or disclosed.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold text-text-dark mb-2">5. Contact Us</h2>
            <p>
              If you have any questions about this privacy policy or our privacy practices, please contact us at <strong>gurmeetkaurstore@gmail.com</strong>.
            </p>
          </section>
        </div>
      );
    } else if (title === 'Terms of Service') {
      return (
        <div className="space-y-6 text-sm text-gray-600 leading-relaxed">
          <section>
            <h2 className="text-lg font-bold text-text-dark mb-2">1. Terms</h2>
            <p>
              By accessing the website at Gurmeet Kaur Store, you are agreeing to be bound by these terms of service, all applicable laws and regulations, and agree that you are responsible for compliance with any applicable local laws.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold text-text-dark mb-2">2. Use License</h2>
            <p>
              Permission is granted to temporarily download one copy of the materials (information or software) on Gurmeet Kaur Store's website for personal, non-commercial transitory viewing only. This is the grant of a license, not a transfer of title.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold text-text-dark mb-2">3. Disclaimer</h2>
            <p>
              The materials on Gurmeet Kaur Store's website are provided on an 'as is' basis. Gurmeet Kaur Store makes no warranties, expressed or implied, and hereby disclaims and negates all other warranties including, without limitation, implied warranties or conditions of merchantability, fitness for a particular purpose, or non-infringement of intellectual property or other violation of rights.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold text-text-dark mb-2">4. Limitations</h2>
            <p>
              In no event shall Gurmeet Kaur Store or its suppliers be liable for any damages (including, without limitation, damages for loss of data or profit, or due to business interruption) arising out of the use or inability to use the materials on Gurmeet Kaur Store's website.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-bold text-text-dark mb-2">5. Products & Purchases</h2>
            <p>
              All products shown on our site are subject to availability. We reserve the right to limit the quantities of any products or services that we offer. All descriptions of products or product pricing are subject to change at anytime without notice.
            </p>
          </section>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="flex flex-col h-full bg-brand-light pb-24">
      <div className="bg-white p-4 flex items-center border-b border-brand-muted sticky top-0 z-20 shadow-sm">
        <button onClick={onBack} className="p-2 hover:bg-brand-soft rounded-full transition-colors mr-2">
          <ChevronLeft size={24} className="text-brand-primary" />
        </button>
        <h1 className="text-xl font-bold text-text-dark">{title}</h1>
      </div>

      <div className="p-4">
        <div className="bg-white p-6 md:p-8 rounded-[32px] border border-brand-muted shadow-sm">
          {getDocumentContent()}
        </div>
      </div>
    </div>
  );
}
